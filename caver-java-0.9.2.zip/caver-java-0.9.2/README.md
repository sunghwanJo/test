# Caverj 
Java SDK for klaytn

Features
--------
##### Klaytn Platform API
- [klay rpc](<https://docs.klaytn.com/api/platform/klay>)
- [net rpc](<https://docs.klaytn.com/api/platform/net>)

##### Transactions
*https://docs.klaytn.com/klaytn/design/transactions*
- TxTypeLegacyTransaction

- **ValueTransfer**
  - TxTypeValueTransfer
  - TxTypeFeeDelegatedValueTransfer
  - TxTypeFeeDelegatedValueTransferWithRatio
  - TxTypeValueTransferMemo
  - TxTypeFeeDelegatedValueTransferMemo
  - TxTypeFeeDelegatedValueTransferMemoWithRatio
- **AccountCreation**
  - TxTypeAccountCreation
- **AccountUpdate**
  - TxTypeAccountUpdate
  - TxTypeFeeDelegatedAccountUpdate
  - TxTypeFeeDelegatedAccountUpdateWithRatio
- **SmartContractDeploy**
  - TxTypeSmartContractDeploy
  - TxTypeFeeDelegatedSmartContractDeploy
  - TxTypeFeeDelegatedSmartContractDeployWithRatio
- **SmartContractExecution**
  - TxTypeSmartContractExecution
  - TxTypeFeeDelegatedSmartContractExecution
  - TxTypeFeeDelegatedSmartContractExecutionWithRatio
- **Cancel**
  - TxTypeCancel
  - TxTypeFeeDelegatedCancel
  - TxTypeFeeDelegatedCancelWithRatio

##### Account Key
*https://docs.klaytn.com/klaytn/design/account*
- AccountKeyNil
- AccountKeyLegacy
- AccountKeyPublic
- AccountKeyFail
- AccountKeyWeightedMultiSig
- AccountKeyRoleBasedRLPBytes

##### Human Readable Account
https://docs.klaytn.com/klaytn/design/account#human-readable-address

Getting started
---------------
### Gradle
Add repository
```groovy
repositories {
    maven {
        url "http://nexus.groundx.xyz/repository/maven-releases"
    }
    ...
}
```
Add dependencies
```groovy
dependencies {
    implementation group: 'com.klaytn.caver', name: 'caver', version: $caver_version
}
```

### Maven
#### Java 8
Add repository
```xml
<distributionManagement>
    <repository>
        <id>groundxRepository</id>
        <name>maven-releases</name>
        <url>http://nexus.groundx.xyz/repository/maven-releases/</url>
    </repository>
</distributionManagement>
```
Add dependencies
```xml
<dependency>
    <groupId>com.klaytn.caver</groupId>
    <artifactId>caver</artifactId>
    <version>0.0.2</version>
</dependency>
```

### Android
Rename `${caverj-version}` to `${caverj-version}-android`

Start sending requests
----------------------
*Platform API (e.g. [klay_chainId](<https://docs.klaytn.com/api/platform/klay#klay_chainid>)*)
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
Quantity response = caverj.klay().getChainId().send();
BigInteger chindId = response.getValue();
```


Create & Load credentials
----------------------
##### Generate credentials
```java
String credentialFileName = KlayWalletUtils.generateNewWalletFile(/*password*/, new File(/*directory*/));
```

or download from [klaytnwallet](<https://baobab.klaytnwallet.com/create>)


##### Load credentials from file
```java
KlayCredentials credentials = KlayWalletUtils.loadCredentials(/*password*/, /*filepath*/);
```
##### Load credentials from private key
```java
KlayCredentials credentials = KlayCredentials.create(/*private key*/);
```

Value Transfer
----------------------
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");

BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger(); 
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials from = KlayCredentials.create(/*from_private_key*/);
KlayCredentials to = KlayCredentials.create(/*to_private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        from.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

TxTypeValueTransfer tx = TxTypeValueTransfer.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        from.getAddress(),
        to.getAddress(),
        Convert.toPeb("1", Convert.Unit.KPEB).toBigInteger());

KlayRawTransaction rawTx = tx.sign(from, baobabChainId);

caverj.klay().sendSignedTransaction(rawTx.getValueAsString()).send();
```
Fee Delegated Value Transfer 
----------------------
*Sender Client*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
        
BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials from = KlayCredentials.create(/*from_private_key*/);
KlayCredentials to = KlayCredentials.create(/*to_private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        from.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

TxTypeFeeDelegatedValueTransfer tx = TxTypeFeeDelegatedValueTransfer.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        from.getAddress(),
        to.getAddress(),
        Convert.toPeb("1", Convert.Unit.KPEB).toBigInteger());

KlayRawTransaction rawTx = tx.sign(from, baobabChainId);
String rawTxString = rawTx.getValueAsString();
```

*FeePayer Client*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");

KlayCredentials feePayerCredential = KlayCredentials.create(/*fee_payer_private_key*/);
int baobabChainId = 1001;
String rawTxString = /*signed sender transaction*/

FeePayer feePayer = new FeePayer(feePayerCredential, baobabChainId);
TxType.Type type = KlayTransactionDecoder.getType(rawTxString);
if(type == TxType.Type.FEE_DELEGATED_VALUE_TRANSFER) {
    TxTypeFeeDelegatedValueTransfer senderTx = TxTypeFeeDelegatedValueTransfer.decodeFromRawTransaction(rawTxString);
    KlayRawTransaction payerTx = feePayer.sign(senderTx);
    Bytes32 response = caverj.klay().sendSignedTransaction(payerTx.getValueAsString()).send();
}
```

Fee Delegated Contract Deploy
----------------------------
*Sender Client*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
        
BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials credentials = KlayCredentials.create(/*private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

TxTypeFeeDelegatedSmartContractDeploy contractDeploy = TxTypeFeeDelegatedSmartContractDeploy.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        /*contractAddress*/,
        BigInteger.ZERO,
        credentials.getAddress(),
        /*payload*/
);

KlayRawTransaction rawTx = contractDeploy.sign(credentials, baobabChainId);
String rawTxString = rawTx.getValueAsString();
```

*FeePayer Client*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");

KlayCredentials feePayerCredential = KlayCredentials.create(/*fee_payer_private_key*/);
int baobabChainId = 1001;
String rawTxString = /*signed sender transaction*/

TxType.Type type = KlayTransactionDecoder.getType(rawTxString);
FeePayer feePayer = new FeePayer(feePayerCredential, baobabChainId);
if(type == TxType.Type.FEE_DELEGATED_SMART_CONTRACT_DEPLOY) {
    TxTypeFeeDelegatedSmartContractDeploy senderTx = TxTypeFeeDelegatedSmartContractDeploy.decodeFromRawTransaction(rawTxString);
    KlayRawTransaction payerTx = feePayer.sign(senderTx);
    Bytes32 response = caverj.klay().sendSignedTransaction(payerTx.getValueAsString()).send();
}
```


Contract Execution
----------------------------
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
        
BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials credentials = KlayCredentials.create(/*private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

TxTypeSmartContractExecution typeSmartContractExecution = TxTypeSmartContractExecution.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        /*contractAddress*/,
        BigInteger.ZERO,
        credentials.getAddress(),
        /*payload*/
);

KlayRawTransaction signedExecutionTx = typeSmartContractExecution.sign(credentials, baobabChainId);
Bytes32 contractExecutionHash = caverj.klay().sendSignedTransaction(signedExecutionTx.getValueAsString()).send();
```

Account Creation
----------------------------
*HumanReadable + AccountKeyPublic*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
        
BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials credentials = KlayCredentials.create(/*private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

TxTypeAccountCreation accountPublicCreation = TxTypeAccountCreation.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        /*humanReadable Address*/,
        BigInteger.ZERO,
        credentials.getAddress(),
        /*publicKey*/
);

KlayRawTransaction accountPublicCreationTx = accountPublicCreation.sign(credentials, baobabChainId);
Bytes32 accountPublicCreationHash = caverj.klay().sendSignedTransaction(accountPublicCreationTx.getValueAsString()).send();
```

*HumanReadable + AccountKeyWeightedMultiSig*
```java
Caverj caverj = Caverj.build("https://api.baobab.klaytn.net:8651");
        
BigInteger gasPrice = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
BigInteger gasLimit = BigInteger.valueOf(4_300_000);
KlayCredentials credentials = KlayCredentials.create(/*private_key*/);
int baobabChainId = 1001;

BigInteger nonce = caverj.klay().getTransactionCount(
        credentials.getAddress(), DefaultBlockParameterName.LATEST).sendAsync().get().getValue();

AccountKeyPublic public1 = AccountKeyPublic.create(Numeric.toBigInt(/*publicKey1*/)); 
AccountKeyPublic public2 = AccountKeyPublic.create(Numeric.toBigInt(/*publicKey2*/)); 
AccountKeyPublic public3 = AccountKeyPublic.create(Numeric.toBigInt(/*publicKey3*/)); 
TxTypeAccountCreation accountMultiSigCreation = TxTypeAccountCreation.createTransaction(
        nonce,
        gasPrice,
        gasLimit,
        /*humanReadable Address*/,
        BigInteger.ZERO,
        credentials.getAddress(),
        AccountKeyWeightedMultiSig.create(
                BigInteger.valueOf(/*threshold*/),
                Arrays.asList(
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(/*wegiht*/), public1.getPublicKeyX(), public1.getPublicKeyY()
                        ),
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(/*wegiht*/), public2.getPublicKeyX(), public2.getPublicKeyY()
                        ),
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(/*wegiht*/), public3.getPublicKeyX(), public3.getPublicKeyY()
                        )
                )
        )
);

KlayRawTransaction accountMultiSigCreationTx = accountMultiSigCreation.sign(credentials, baobabChainId);
Bytes32 accountMultiSigCreationHash = caverj.klay().sendSignedTransaction(accountMultiSigCreationTx.getValueAsString()).send();
```

Transaction Manager
-------------------
```java
Caverj caverj = Caverj.build(Caverj.BAOBAB_URL);
WalletManager walletManager = new WalletManager();
walletManager.add(/*klay credentials*/);
TransactionManager transactionManager = TransactionManager.create(caverj, walletManager);

ValueTransfer valueTransfer = ValueTransfer
                .create(/*from*/, /*to */, /*amount*/, /*gas limit*/);

KlayTransactionReceipt.TransactionReceipt transactionReceipt = transactionManager.executeTransaction(valueTransfer);
```


FeePayer Manager
----------------
```java
KlayCredentials feePayerCredentials = KlayWalletUtils.loadCredentials(/*password*/, /*keystore filepath*/);

FeePayerManager feePayerManager = FeePayerManager.create(caverj, feePayerCredentials);
KlayTransactionReceipt.TransactionReceipt transactionReceipt = feePayerManager.executeTransaction(senderTx);
```


Error Code Improvement
----------------------
The value of `txError` of the transaction receipt like the below:
```
 {
  "blockHash": "0xe7ec35c9fff1178d52cee1d46d40627d19f828c4b06ad1a5c3807698b99acb20",
  "blockNumber": 7811,
  "contractAddress": null,
  "from": "0xa8a2d37727197cc0eb827f8c5a3a3aceb26cf59e",
  "gasUsed": 9900000000,
  "logsBloom": "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
  "status": false,
  "to": "0xf8425b0f65147969621f9390ca06139c7b439497",
  "transactionHash": "0x85ce2b307899c90144442d9b3236827ac57375c522be2435093aebfd920b8c58",
  "transactionIndex": 0,
  "txError": "0x2",
  "events": {}
}
```
The meaning of error code can be found below:
```
{
  "0x2": 'runtime error occurred in interpreter',
  "0x3": 'max call depth exceeded',
  "0x4": 'contract address collision',
  "0x5": 'contract creation code storage out of gas',
  "0x6": 'evm: max code size exceeded',
  "0x7": 'out of gas',
  "0x8": 'evm: write protection',
  "0x9": 'evm: execution reverted',
  "0xa": 'reached the opcode count limit',
  "0xb": 'account already exists',
  "0xc": 'not a program account (e.g., an account having code and storage)',
  "0xd": 'not a human readable address',
  "0xe": "fee ratio is out of range [1, 99]", 
  "0xf": "AccountKeyFail is not updatable", 
  "0x10": "different account key type", 
  "0x11": "AccountKeyNil cannot be initialized to an account", 
  "0x12": "public key is not on curve", 
  "0x13": "key weight is zero", 
  "0x14": "key is not serializable", 
  "0x15": "duplicated key", 
  "0x16": "weighted sum overflow", 
  "0x17": "unsatisfiable threshold. Weighted sum of keys is less than the threshold.", 
  "0x18": "length is zero", 
  "0x19": "length too long", 
  "0x1a": "nested role-based key", 
}
```

# Differences between previous Version and Version v0.0.3
### Renamed method `Caverj.klaytn` to `Caverj.klay`

### Added `Caverj.klay()` RPC
* klay_accountCreated
* klay_isContractAccount
* klay_isHumanReadable
* klay_call
* klay_sign
* klay_estimateGas
* klay_getBlockByNumber
* klay_getBlockReceipts
* klay_getTransactionByHash
* klay_getTransactionByBlockHashAndIndex
* klay_newFilter
* klay_newPendingTransactionFilter
* klay_unisntallFilter
* klay_getFilterChanges
* klay_getFilterLogs
* klay_getLogs
* klay_getWork
* klay_getblockWithConsensusInfoByHash
* klay_getBlockWithConsensusInfoByNumber

### Added `Caverj.net()` RPC
* net_networkID
* net_listening
* net_peerCount

### Added `AccountKey`
* AccountKeyNil
* AccountKeyLegacy
* AccountKeyFail
* AccountKeyPublic
* AccountKeyRoleBased
* AccountKeyRoleBasedRLPBytes

### Added `Response Type`
* Bytes20
* Bytes32
* Bytes
* Boolean
* BlockReceipts
* KlayBlock
* KlayBlockWithConsensusInfo
* KlayLogs
* KlaySignTransaction
* Addresses
* Work

### Added `HumanReadableAddress`
* If `from`, `to` of Transactions is `"^[A-Za-z][0-9A-Za-z]{4,12}$"`, it is recognized as human readable address.
* Identifier `.klaytn` is appended as a postfix of a human readable address.
* remove `isHumanReadable` parameter of createTransactions (automatically applied according to `to`)


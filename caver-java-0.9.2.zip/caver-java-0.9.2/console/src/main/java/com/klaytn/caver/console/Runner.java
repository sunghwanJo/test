package com.klaytn.caver.console;

import com.klaytn.caver.codegen.Console;
import com.klaytn.caver.codegen.SolidityFunctionWrapperGenerator;
import com.klaytn.caver.codegen.TruffleJsonFunctionWrapperGenerator;
import org.web3j.utils.Collection;

/**
 * Main entry point for running command line utilities.
 */
public class Runner {

    private static String USAGE = "Usage: caver-java solidity|truffle ...";

    private static String LOGO = "\n" // generated at http://patorjk.com/software/taag
     + "     ________  ________  ___      ___ _______   ________       ___      \n"
     + "    |\\   ____\\|\\   __  \\|\\  \\    /  /|\\  ___ \\ |\\   __  \\     |\\  \\     \n"
     + "    \\ \\  \\___|\\ \\  \\|\\  \\ \\  \\  /  / | \\   __/|\\ \\  \\|\\  \\    \\ \\  \\    \n"
     + "     \\ \\  \\    \\ \\   __  \\ \\  \\/  / / \\ \\  \\_|/_\\ \\   _  _\\  __ \\ \\  \\   \n"
     + "      \\ \\  \\____\\ \\  \\ \\  \\ \\    / /   \\ \\  \\_|\\ \\ \\  \\ \\  \\|\\  \\ \\_\\ \\  \n"
     + "       \\ \\_______\\ \\__\\ \\__\\ \\__/ /     \\ \\_______\\ \\__\\ \\ _\\ \\________\\ \n"
     + "        \\|_______|\\|__|\\|__|\\|__|/       \\|_______|\\|__|\\ |__\\|________| \n";



    public static void main(String[] args) throws Exception {
        System.out.println(LOGO);

        if (args.length < 1) {
            Console.exitError(USAGE);
        } else {
            switch (args[0]) {
                case SolidityFunctionWrapperGenerator.COMMAND_SOLIDITY:
                    SolidityFunctionWrapperGenerator.main(Collection.tail(args));
                    break;
                case TruffleJsonFunctionWrapperGenerator.COMMAND_TRUFFLE:
                    TruffleJsonFunctionWrapperGenerator.run(Collection.tail(args));
                    break;
                default:
                    Console.exitError(USAGE);
            }
        }
    }
}

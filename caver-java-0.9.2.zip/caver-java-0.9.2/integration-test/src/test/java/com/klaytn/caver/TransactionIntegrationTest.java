package com.klaytn.caver;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.model.AbstractTest;
import com.klaytn.caver.model.Env;
import com.klaytn.caver.model.TestData;
import org.junit.Before;
import org.junit.Test;
import org.web3j.protocol.Web3jService;
import org.web3j.protocol.http.HttpService;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.util.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class TransactionIntegrationTest {

    private ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private KlayCredentials sender;
    private Caver caver;
    private Web3jService service;

    @Before
    public void setUp() throws Exception {
        URL envUrl = getClass().getClassLoader().getResource("klaytn-intergration-tests" + File.separator + "env.json");
        File envFile = new File(envUrl.toURI());
        Env env = readFile(envFile, Env.class);

        sender = KlayCredentials.create(env.getSender().getPrivateKey(), env.getSender().getAddress());
        caver = Caver.build(env.getURL());
        service = new HttpService(env.getURL());
    }

    @Test
    public void INT_LEGACY() throws Exception {
        Set<String> skipSet = new HashSet<>();
        readDirectoryAndExecute("INT-LEGACY", skipSet);
    }

    @Test
    public void VALUE_TRANSFER() throws Exception {
        Set<String> skipSet = new HashSet<>();
        readDirectoryAndExecute("INT-VT", skipSet);
    }

    @Test
    public void VALUE_TRANSFER_MEMO() throws Exception {
        Set<String> skipSet = new HashSet<>(Arrays.asList());
        readDirectoryAndExecute("INT-VTM", skipSet);
    }

    @Test
    public void ACCOUNT_CREATION() throws Exception {
        Set<String> skipSet = new HashSet<>(Arrays.asList("042.json", "048.json", "049.json", "050.json", "063.json"));
        readDirectoryAndExecute("INT-ACCCRE", skipSet);
    }

    @Test
    public void SMART_CONTRACT_DEPLOY() throws Exception {
        Set<String> skipSet = new HashSet<>(Arrays.asList());
        readDirectoryAndExecute("INT-DEPL", skipSet);
    }

    @Test
    public void testIntegrationSolidity() throws Exception {
        String dirName = "INT-SOL";
        Set<String> skipSet = new HashSet<>(Collections.emptyList());
        URL url = getClass().getClassLoader().getResource("klaytn-intergration-tests" + File.separator + dirName);
        File dir = new File(url.toURI());
        File[] directoryListing = Arrays.stream(Objects.requireNonNull(dir.listFiles()))
                .filter(file -> file.getName().endsWith(".json") && !skipSet.contains(file.getName()))
                .toArray(File[]::new);

        TestData testData;
        for (File file : directoryListing) {
            System.out.printf("\n\n========= reading %s =========", file.getName());
            testData = readFile(file, TestData.class);
            System.out.printf("\n========= %s %s started =========\n\n", testData.getTcID(), testData.getTcName());

            for (AbstractTest abstractTest : testData.getTest()) {
                abstractTest.configure(caver, service, sender);
                abstractTest.execute();
            }

            System.out.printf("\n\n========= %s %s finished =========\n\n", testData.getTcID(), testData.getTcName());
        }
    }

    private void readDirectoryAndExecute(String dirName, Set<String> skipSet) throws Exception {
        URL url = getClass().getClassLoader().getResource("klaytn-intergration-tests" + File.separator + dirName);
        File dir = new File(url.toURI());
        File[] directoryListing = Arrays.stream(Objects.requireNonNull(dir.listFiles()))
                .filter(file -> file.getName().endsWith(".json") && !skipSet.contains(file.getName()))
                .toArray(File[]::new);

        TestData testData;
        for (File file : directoryListing) {
            System.out.printf("\n\n========= reading %s =========", file.getName());
            testData = readFile(file, TestData.class);
            System.out.printf("\n========= %s %s started =========\n\n", testData.getTcID(), testData.getTcName());

            for (AbstractTest abstractTest : testData.getTest()) {
                abstractTest.configure(caver, service, sender);
                abstractTest.execute();
            }

            System.out.printf("\n\n========= %s %s finished =========\n\n", testData.getTcID(), testData.getTcName());
        }
    }

    private String getCurrentPath() {
        return "src/test/java/com/klaytn/caver/integration/";
    }

    private <T> T readFile(File file, Class<T> clazz) throws Exception {
        try (InputStream fileStream = new FileInputStream(file)) {
            return objectMapper.readValue(fileStream, clazz);
        }
    }

}
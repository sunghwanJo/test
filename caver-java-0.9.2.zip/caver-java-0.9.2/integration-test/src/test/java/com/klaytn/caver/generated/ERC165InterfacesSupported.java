package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.util.Arrays;
import java.util.List;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Bytes4;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class ERC165InterfacesSupported extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b506040516102b63803806102b68339810180604052602081101561003357600080fd5b81019080805164010000000081111561004b57600080fd5b8201602081018481111561005e57600080fd5b815185602082028301116401000000008211171561007b57600080fd5b50509291905050506100996301ffc9a760e01b6100d660201b60201c565b60005b81518110156100cf576100c78282815181106100b457fe5b60200260200101516100d660201b60201c565b60010161009c565b505061018e565b7fffffffff000000000000000000000000000000000000000000000000000000008082161415610151576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602f815260200180610287602f913960400191505060405180910390fd5b7fffffffff00000000000000000000000000000000000000000000000000000000166000908152602081905260409020805460ff19166001179055565b60eb8061019c6000396000f3fe6080604052348015600f57600080fd5b506004361060325760003560e01c806301ffc9a714603757806334d7006c14606f575b600080fd5b605b60048036036020811015604b57600080fd5b50356001600160e01b0319166092565b604080519115158252519081900360200190f35b607560b1565b604080516001600160e01b03199092168252519081900360200190f35b6001600160e01b03191660009081526020819052604090205460ff1690565b600160e01b6301ffc9a7028156fea165627a7a7230582001fa32a13c6ef53019eb5efccdafa531600e38b20ab6e1b75660de3f3b619bc30029455243313635496e7465726661636573537570706f727465643a20696e76616c696420696e74657266616365206964";

    public static final String FUNC_SUPPORTSINTERFACE = "supportsInterface";

    public static final String FUNC_INTERFACE_ID_ERC165 = "INTERFACE_ID_ERC165";

    protected ERC165InterfacesSupported(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected ERC165InterfacesSupported(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<Boolean> supportsInterface(byte[] interfaceId) {
        final Function function = new Function(FUNC_SUPPORTSINTERFACE, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes4(interfaceId)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<byte[]> INTERFACE_ID_ERC165() {
        final Function function = new Function(FUNC_INTERFACE_ID_ERC165, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bytes4>() {}));
        return executeRemoteCallSingleValueReturn(function, byte[].class);
    }

    public static ERC165InterfacesSupported load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new ERC165InterfacesSupported(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static ERC165InterfacesSupported load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new ERC165InterfacesSupported(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<ERC165InterfacesSupported> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider, List<byte[]> interfaceIds) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.DynamicArray<org.web3j.abi.datatypes.generated.Bytes4>(
                        org.web3j.abi.datatypes.generated.Bytes4.class,
                        org.web3j.abi.Utils.typeMap(interfaceIds, org.web3j.abi.datatypes.generated.Bytes4.class))));
        return deployRemoteCall(ERC165InterfacesSupported.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<ERC165InterfacesSupported> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider, List<byte[]> interfaceIds) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.DynamicArray<org.web3j.abi.datatypes.generated.Bytes4>(
                        org.web3j.abi.datatypes.generated.Bytes4.class,
                        org.web3j.abi.Utils.typeMap(interfaceIds, org.web3j.abi.datatypes.generated.Bytes4.class))));
        return deployRemoteCall(ERC165InterfacesSupported.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<ERC165InterfacesSupported> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider, List<byte[]> interfaceIds) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.DynamicArray<org.web3j.abi.datatypes.generated.Bytes4>(
                        org.web3j.abi.datatypes.generated.Bytes4.class,
                        org.web3j.abi.Utils.typeMap(interfaceIds, org.web3j.abi.datatypes.generated.Bytes4.class))));
        return deployRemoteCall(ERC165InterfacesSupported.class, caverj, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<ERC165InterfacesSupported> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider, List<byte[]> interfaceIds) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.DynamicArray<org.web3j.abi.datatypes.generated.Bytes4>(
                        org.web3j.abi.datatypes.generated.Bytes4.class,
                        org.web3j.abi.Utils.typeMap(interfaceIds, org.web3j.abi.datatypes.generated.Bytes4.class))));
        return deployRemoteCall(ERC165InterfacesSupported.class, caverj, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }
}

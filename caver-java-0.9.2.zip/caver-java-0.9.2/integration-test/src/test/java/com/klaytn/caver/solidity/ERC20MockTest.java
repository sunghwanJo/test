package com.klaytn.caver.solidity;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.generated.ERC20Mock;
import com.klaytn.caver.tx.gas.DefaultGasProvider;
import com.klaytn.caver.tx.manager.TransactionManager;
import junit.framework.TestCase;
import org.junit.Test;

import java.math.BigInteger;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

public class ERC20MockTest extends TestCase {

    private Caver caver = Caver.build();
    private KlayCredentials credentials = KlayCredentials.create("0xb8fb92462d3d303def7f5eda6f3a133229b8446d3c1e73e1e377d4205ab0ae4b");
    // 0x2c8ad0ea2e0781db8b8c9242e07de3a5beabb71a
    private DefaultGasProvider gasProvider = new DefaultGasProvider();
    private String sender = credentials.getAddress();
    private BigInteger initialBalance = BigInteger.valueOf(100_000_000);
    private TransactionManager transactionManager = new TransactionManager.Builder(caver, credentials)
            .setChaindId(2019)
            .build();
    private ERC20Mock erc20Mock;

    private String fakeSender = "0x18fd72128ae95d0c72dc1301db27371cb22cd0ad";

    @Override
    public void setUp() throws Exception {
        erc20Mock = ERC20Mock.deploy(caver, transactionManager, gasProvider, sender, initialBalance).send();
    }

    @Test
    public void testTotalSupply() throws Exception {
        assertThat(
                erc20Mock.totalSupply().send(),
                is(initialBalance)
        );
    }

    @Test
    public void testBalanceOfToken() throws Exception {
        assertThat(
                erc20Mock.balanceOf(sender).send(),
                is(initialBalance)
        );
    }

    @Test
    public void testBalanceOfNoToken() throws Exception {
        assertThat(
                erc20Mock.balanceOf(fakeSender).send(),
                is(BigInteger.ZERO)
        );
    }

    @Test
    public void testNotEnoughBalance() throws Exception {
        assertThat(
                erc20Mock.transfer(fakeSender, initialBalance.add(BigInteger.ONE)).send().getStatus(),
                not("hi?")
        );
    }

    @Test
    public void testEnoughBalance() throws Exception {
        erc20Mock.transfer(fakeSender, initialBalance).send();
        assertThat(erc20Mock.balanceOf(sender).send(), is(BigInteger.ZERO));
        assertThat(erc20Mock.balanceOf(fakeSender).send(), is(initialBalance));

    }

}

package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayLogs;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class SignatureBouncerMock extends SmartContract {
    private static final String BINARY = "60806040526100133361001860201b60201c565b610189565b61003081600061006760201b610c611790919060201c565b6040516001600160a01b038216907f47d1c22a25bb3a5d4e481b9b1e6944c2eade3181a0a20b495ed61d35b5323f2490600090a250565b610077828261010860201b60201c565b156100e357604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601f60248201527f526f6c65733a206163636f756e7420616c72656164792068617320726f6c6500604482015290519081900360640190fd5b6001600160a01b0316600090815260209190915260409020805460ff19166001179055565b60006001600160a01b038216610169576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260228152602001806111866022913960400191505060405180910390fd5b506001600160a01b03166000908152602091909152604090205460ff1690565b610fee806101986000396000f3fe608060405234801561001057600080fd5b50600436106100cf5760003560e01c80638263ac0c1161008c578063b44e2ab911610066578063b44e2ab914610676578063ca422c431461067e578063e5c8b03d14610686578063eb12d61e1461068e576100cf565b80638263ac0c146103e6578063997027e81461048a578063b20bdb68146105cb576100cf565b80630e316ab7146100d45780636123f7ba146100fc57806368b51ac7146101a05780636b802108146102685780636d5b94271461031c5780637df73e27146103c0575b600080fd5b6100fa600480360360208110156100ea57600080fd5b50356001600160a01b03166106b4565b005b6100fa6004803603602081101561011257600080fd5b810190602081018135600160201b81111561012c57600080fd5b82018360208201111561013e57600080fd5b803590602001918460018302840111600160201b8311171561015f57600080fd5b91908080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152509295506106c0945050505050565b610254600480360360408110156101b657600080fd5b6001600160a01b038235169190810190604081016020820135600160201b8111156101e057600080fd5b8201836020820111156101f257600080fd5b803590602001918460018302840111600160201b8311171561021357600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092955061070d945050505050565b604080519115158252519081900360200190f35b6102546004803603604081101561027e57600080fd5b6001600160a01b038235169190810190604081016020820135600160201b8111156102a857600080fd5b8201836020820111156102ba57600080fd5b803590602001918460018302840111600160201b831117156102db57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610722945050505050565b6100fa6004803603602081101561033257600080fd5b810190602081018135600160201b81111561034c57600080fd5b82018360208201111561035e57600080fd5b803590602001918460018302840111600160201b8311171561037f57600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092955061072e945050505050565b610254600480360360208110156103d657600080fd5b50356001600160a01b0316610777565b6100fa600480360360208110156103fc57600080fd5b810190602081018135600160201b81111561041657600080fd5b82018360208201111561042857600080fd5b803590602001918460018302840111600160201b8311171561044957600080fd5b91908080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152509295506106bd945050505050565b610254600480360360808110156104a057600080fd5b6001600160a01b038235169190810190604081016020820135600160201b8111156104ca57600080fd5b8201836020820111156104dc57600080fd5b803590602001918460018302840111600160201b831117156104fd57600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092958435959094909350604081019250602001359050600160201b81111561055757600080fd5b82018360208201111561056957600080fd5b803590602001918460018302840111600160201b8311171561058a57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610789945050505050565b6100fa600480360360408110156105e157600080fd5b81359190810190604081016020820135600160201b81111561060257600080fd5b82018360208201111561061457600080fd5b803590602001918460018302840111600160201b8311171561063557600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092955061079e945050505050565b6100fa6107ec565b6100fa610835565b6100fa61088d565b6100fa600480360360208110156106a457600080fd5b50356001600160a01b0316610896565b6106bd816108e6565b50565b806106cb33826108ef565b61070957604051600160e51b62461bcd028152600401808060200182810382526039815260200180610f536039913960400191505060405180910390fd5b5050565b60006107198383610a1c565b90505b92915050565b600061071983836108ef565b806107393382610a1c565b61070957604051600160e51b62461bcd02815260040180806020018281038252602e815260200180610f25602e913960400191505060405180910390fd5b600061071c818363ffffffff610a6516565b60006107958583610acf565b95945050505050565b806107a93382610acf565b6107e757604051600160e51b62461bcd028152600401808060200182810382526037815260200180610f8c6037913960400191505060405180910390fd5b505050565b6107f533610777565b61083357604051600160e51b62461bcd028152600401808060200182810382526030815260200180610ef56030913960400191505060405180910390fd5b565b6040518060200160405280600081525061084f3382610acf565b6106bd57604051600160e51b62461bcd028152600401808060200182810382526037815260200180610f8c6037913960400191505060405180910390fd5b610833336108e6565b61089f33610777565b6108dd57604051600160e51b62461bcd028152600401808060200182810382526030815260200180610ef56030913960400191505060405180910390fd5b6106bd81610b97565b6106bd81610bdf565b6040805160048082528183019092526000916060919060208201818038833901905050905060005b8151811015610962576000368281811061092d57fe5b9050013560f81c60f81b82828151811061094357fe5b60200101906001600160f81b031916908160001a905350600101610917565b50610a1430858360405160200180846001600160a01b03166001600160a01b031660601b8152601401836001600160a01b03166001600160a01b031660601b815260140182805190602001908083835b602083106109d15780518252601f1990920191602091820191016109b2565b6001836020036101000a03801982511681845116808217855250505050505090500193505050506040516020818303038152906040528051906020012084610c27565b949350505050565b6040805130606090811b6020808401919091526001600160a01b03861690911b603483015282516028818403018152604890920190925280519101206000906107199083610c27565b60006001600160a01b038216610aaf57604051600160e51b62461bcd028152600401808060200182810382526022815260200180610ed36022913960400191505060405180910390fd5b506001600160a01b03166000908152602091909152604090205460ff1690565b600060603611610b1357604051600160e51b62461bcd028152600401808060200182810382526023815260200180610e8f6023913960400191505060405180910390fd5b6060806000369050036040519080825280601f01601f191660200182016040528015610b46576020820181803883390190505b50905060005b81518110156109625760003682818110610b6257fe5b9050013560f81c60f81b828281518110610b7857fe5b60200101906001600160f81b031916908160001a905350600101610b4c565b610ba860008263ffffffff610c6116565b6040516001600160a01b038216907f47d1c22a25bb3a5d4e481b9b1e6944c2eade3181a0a20b495ed61d35b5323f2490600090a250565b610bf060008263ffffffff610ce516565b6040516001600160a01b038216907f3525e22824a8a7df2c9a6029941c824cf95b6447f1e13d5128fd3826d35afe8b90600090a250565b600080610c4383610c3786610d4f565b9063ffffffff610da016565b90506001600160a01b03811615801590610a145750610a1481610777565b610c6b8282610a65565b15610cc05760408051600160e51b62461bcd02815260206004820152601f60248201527f526f6c65733a206163636f756e7420616c72656164792068617320726f6c6500604482015290519081900360640190fd5b6001600160a01b0316600090815260209190915260409020805460ff19166001179055565b610cef8282610a65565b610d2d57604051600160e51b62461bcd028152600401808060200182810382526021815260200180610eb26021913960400191505060405180910390fd5b6001600160a01b0316600090815260209190915260409020805460ff19169055565b604080517f19457468657265756d205369676e6564204d6573736167653a0a333200000000602080830191909152603c8083019490945282518083039094018452605c909101909152815191012090565b60008151604114610db35750600061071c565b60208201516040830151606084015160001a7f7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0821115610df9576000935050505061071c565b8060ff16601b14158015610e1157508060ff16601c14155b15610e22576000935050505061071c565b6040805160008152602080820180845289905260ff8416828401526060820186905260808201859052915160019260a0808401939192601f1981019281900390910190855afa158015610e79573d6000803e3d6000fd5b5050604051601f19015197965050505050505056fe5369676e6174757265426f756e6365723a206461746120697320746f6f2073686f7274526f6c65733a206163636f756e7420646f6573206e6f74206861766520726f6c65526f6c65733a206163636f756e7420697320746865207a65726f20616464726573735369676e6572526f6c653a2063616c6c657220646f6573206e6f74206861766520746865205369676e657220726f6c655369676e6174757265426f756e6365723a20696e76616c6964207369676e617475726520666f722063616c6c65725369676e6174757265426f756e6365723a20696e76616c6964207369676e617475726520666f722063616c6c657220616e64206d6574686f645369676e6174757265426f756e6365723a20696e76616c6964207369676e617475726520666f722063616c6c657220616e642064617461a165627a7a72305820fb26e47901b4c0435f4c9dccad0426e66dcc66e4d6fa2105bf20864bcf4224fe0029526f6c65733a206163636f756e7420697320746865207a65726f2061646472657373";

    public static final String FUNC_REMOVESIGNER = "removeSigner";

    public static final String FUNC_ONLYWITHVALIDSIGNATUREANDMETHOD = "onlyWithValidSignatureAndMethod";

    public static final String FUNC_CHECKVALIDSIGNATURE = "checkValidSignature";

    public static final String FUNC_CHECKVALIDSIGNATUREANDMETHOD = "checkValidSignatureAndMethod";

    public static final String FUNC_ONLYWITHVALIDSIGNATURE = "onlyWithValidSignature";

    public static final String FUNC_ISSIGNER = "isSigner";

    public static final String FUNC_THEWRONGMETHOD = "theWrongMethod";

    public static final String FUNC_CHECKVALIDSIGNATUREANDDATA = "checkValidSignatureAndData";

    public static final String FUNC_ONLYWITHVALIDSIGNATUREANDDATA = "onlyWithValidSignatureAndData";

    public static final String FUNC_ONLYSIGNERMOCK = "onlySignerMock";

    public static final String FUNC_TOOSHORTMSGDATA = "tooShortMsgData";

    public static final String FUNC_RENOUNCESIGNER = "renounceSigner";

    public static final String FUNC_ADDSIGNER = "addSigner";

    public static final Event SIGNERADDED_EVENT = new Event("SignerAdded", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}));
    ;

    public static final Event SIGNERREMOVED_EVENT = new Event("SignerRemoved", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}));
    ;

    protected SignatureBouncerMock(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected SignatureBouncerMock(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> removeSigner(String account) {
        final Function function = new Function(
                FUNC_REMOVESIGNER, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public void onlyWithValidSignatureAndMethod(byte[] signature) {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public RemoteCall<Boolean> checkValidSignature(String account, byte[] signature) {
        final Function function = new Function(FUNC_CHECKVALIDSIGNATURE, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account), 
                new org.web3j.abi.datatypes.DynamicBytes(signature)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<Boolean> checkValidSignatureAndMethod(String account, byte[] signature) {
        final Function function = new Function(FUNC_CHECKVALIDSIGNATUREANDMETHOD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account), 
                new org.web3j.abi.datatypes.DynamicBytes(signature)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public void onlyWithValidSignature(byte[] signature) {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public RemoteCall<Boolean> isSigner(String account) {
        final Function function = new Function(FUNC_ISSIGNER, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public void theWrongMethod(byte[] param0) {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public RemoteCall<Boolean> checkValidSignatureAndData(String account, byte[] param1, BigInteger param2, byte[] signature) {
        final Function function = new Function(FUNC_CHECKVALIDSIGNATUREANDDATA, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account), 
                new org.web3j.abi.datatypes.DynamicBytes(param1), 
                new org.web3j.abi.datatypes.generated.Uint256(param2), 
                new org.web3j.abi.datatypes.DynamicBytes(signature)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public void onlyWithValidSignatureAndData(BigInteger param0, byte[] signature) {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public void onlySignerMock() {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public void tooShortMsgData() {
        throw new RuntimeException("cannot call constant function with void return type");
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> renounceSigner() {
        final Function function = new Function(
                FUNC_RENOUNCESIGNER, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> addSigner(String account) {
        final Function function = new Function(
                FUNC_ADDSIGNER, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public List<SignerAddedEventResponse> getSignerAddedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(SIGNERADDED_EVENT, transactionReceipt);
        ArrayList<SignerAddedEventResponse> responses = new ArrayList<SignerAddedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            SignerAddedEventResponse typedResponse = new SignerAddedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.account = (String) eventValues.getIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public List<SignerRemovedEventResponse> getSignerRemovedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(SIGNERREMOVED_EVENT, transactionReceipt);
        ArrayList<SignerRemovedEventResponse> responses = new ArrayList<SignerRemovedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            SignerRemovedEventResponse typedResponse = new SignerRemovedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.account = (String) eventValues.getIndexedValues().get(0).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static SignatureBouncerMock load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new SignatureBouncerMock(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static SignatureBouncerMock load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new SignatureBouncerMock(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<SignatureBouncerMock> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(SignatureBouncerMock.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<SignatureBouncerMock> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(SignatureBouncerMock.class, caverj, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<SignatureBouncerMock> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(SignatureBouncerMock.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<SignatureBouncerMock> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(SignatureBouncerMock.class, caverj, transactionManager, contractGasProvider, BINARY, "");
    }

    public static class SignerAddedEventResponse {
        public KlayLogs.Log log;

        public String account;
    }

    public static class SignerRemovedEventResponse {
        public KlayLogs.Log log;

        public String account;
    }
}

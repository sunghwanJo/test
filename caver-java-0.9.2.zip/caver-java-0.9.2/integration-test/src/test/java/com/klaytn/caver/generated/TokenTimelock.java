package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class TokenTimelock extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b506040516060806105ca8339810180604052606081101561003057600080fd5b5080516020820151604090920151909190428111610099576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260328152602001806105986032913960400191505060405180910390fd5b600080546001600160a01b039485166001600160a01b03199182161790915560018054939094169216919091179091556002556104bd806100db6000396000f3fe608060405234801561001057600080fd5b506004361061004c5760003560e01c806338af3eed1461005157806386d1a69f14610075578063b91d40011461007f578063fc0c546a14610099575b600080fd5b6100596100a1565b604080516001600160a01b039092168252519081900360200190f35b61007d6100b0565b005b6100876101d6565b60408051918252519081900360200190f35b6100596101dc565b6001546001600160a01b031690565b6002544210156100f457604051600160e51b62461bcd0281526004018080602001828103825260328152602001806104136032913960400191505060405180910390fd5b6000805460408051600160e01b6370a0823102815230600482015290516001600160a01b03909216916370a0823191602480820192602092909190829003018186803b15801561014357600080fd5b505afa158015610157573d6000803e3d6000fd5b505050506040513d602081101561016d57600080fd5b50519050806101b057604051600160e51b62461bcd02815260040180806020018281038252602381526020018061046f6023913960400191505060405180910390fd5b6001546000546101d3916001600160a01b0391821691168363ffffffff6101eb16565b50565b60025490565b6000546001600160a01b031690565b604080516001600160a01b038416602482015260448082018490528251808303909101815260649091019091526020810180516001600160e01b0316600160e01b63a9059cbb02179052610240908490610245565b505050565b610257826001600160a01b031661040c565b6102ab5760408051600160e51b62461bcd02815260206004820152601f60248201527f5361666545524332303a2063616c6c20746f206e6f6e2d636f6e747261637400604482015290519081900360640190fd5b60006060836001600160a01b0316836040518082805190602001908083835b602083106102e95780518252601f1990920191602091820191016102ca565b6001836020036101000a0380198251168184511680821785525050505050509050019150506000604051808303816000865af19150503d806000811461034b576040519150601f19603f3d011682016040523d82523d6000602084013e610350565b606091505b5091509150816103aa5760408051600160e51b62461bcd02815260206004820181905260248201527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c6564604482015290519081900360640190fd5b805115610406578080602001905160208110156103c657600080fd5b505161040657604051600160e51b62461bcd02815260040180806020018281038252602a815260200180610445602a913960400191505060405180910390fd5b50505050565b3b15159056fe546f6b656e54696d656c6f636b3a2063757272656e742074696d65206973206265666f72652072656c656173652074696d655361666545524332303a204552433230206f7065726174696f6e20646964206e6f742073756363656564546f6b656e54696d656c6f636b3a206e6f20746f6b656e7320746f2072656c65617365a165627a7a723058200551eb59dfab87e7f69b51aac4cf9efd0e1fca920e9e9bedc47371ca8833f6130029546f6b656e54696d656c6f636b3a2072656c656173652074696d65206973206265666f72652063757272656e742074696d65";

    public static final String FUNC_BENEFICIARY = "beneficiary";

    public static final String FUNC_RELEASE = "release";

    public static final String FUNC_RELEASETIME = "releaseTime";

    public static final String FUNC_TOKEN = "token";

    protected TokenTimelock(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected TokenTimelock(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<String> beneficiary() {
        final Function function = new Function(FUNC_BENEFICIARY, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> release() {
        final Function function = new Function(
                FUNC_RELEASE, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> releaseTime() {
        final Function function = new Function(FUNC_RELEASETIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> token() {
        final Function function = new Function(FUNC_TOKEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public static TokenTimelock load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new TokenTimelock(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static TokenTimelock load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new TokenTimelock(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<TokenTimelock> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider, String token, String beneficiary, BigInteger releaseTime) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.Address(beneficiary), 
                new org.web3j.abi.datatypes.generated.Uint256(releaseTime)));
        return deployRemoteCall(TokenTimelock.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<TokenTimelock> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider, String token, String beneficiary, BigInteger releaseTime) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.Address(beneficiary), 
                new org.web3j.abi.datatypes.generated.Uint256(releaseTime)));
        return deployRemoteCall(TokenTimelock.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<TokenTimelock> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider, String token, String beneficiary, BigInteger releaseTime) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.Address(beneficiary), 
                new org.web3j.abi.datatypes.generated.Uint256(releaseTime)));
        return deployRemoteCall(TokenTimelock.class, caverj, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<TokenTimelock> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider, String token, String beneficiary, BigInteger releaseTime) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.Address(beneficiary), 
                new org.web3j.abi.datatypes.generated.Uint256(releaseTime)));
        return deployRemoteCall(TokenTimelock.class, caverj, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }
}

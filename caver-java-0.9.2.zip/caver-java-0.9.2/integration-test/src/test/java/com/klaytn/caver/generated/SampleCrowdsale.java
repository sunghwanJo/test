package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayLogs;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class SampleCrowdsale extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b5060405160e08062001cbb833981018060405260e081101561003157600080fd5b508051602082015160408301516060840151608085015160a086015160c0909601516001600055949593949293919290919080878785888887826100d657604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f43726f776473616c653a20726174652069732030000000000000000000000000604482015290519081900360640190fd5b6001600160a01b038216610136576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602581526020018062001c966025913960400191505060405180910390fd5b6001600160a01b038116610196576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602481526020018062001c496024913960400191505060405180910390fd5b600392909255600280546001600160a01b039283166001600160a01b031991821617909155600180549290931691161790558061023457604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601960248201527f43617070656443726f776473616c653a20636170206973203000000000000000604482015290519081900360640190fd5b60055542821015610291576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252603381526020018062001bdf6033913960400191505060405180910390fd5b8181116102ea576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252603781526020018062001c126037913960400191505060405180910390fd5b6006919091556007556008805460ff191690558061036957604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601e60248201527f526566756e6461626c6543726f776473616c653a20676f616c20697320300000604482015290519081900360640190fd5b61037761043a60201b60201c565b60405161038390610449565b6001600160a01b03909116815260405190819003602001906000f0801580156103b0573d6000803e3d6000fd5b50600a80546001600160a01b0319166001600160a01b03929092169190911790556009558281111561042e576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602981526020018062001c6d6029913960400191505060405180910390fd5b50505050505050610457565b6002546001600160a01b031690565b610b7b806200106483390190565b610bfd80620004676000396000f3fe6080604052600436106100f35760003560e01c80634f9359451161008a578063b7a8807c11610059578063b7a8807c1461023c578063bffa55d514610251578063ec8ac4d814610284578063fc0c546a146102aa576100f3565b80634f935945146101cc578063521eb273146101e15780637d3d652214610212578063b3f05b9714610227576100f3565b80634042b66f116100c65780634042b66f1461017857806347535d7b1461018d5780634b6753bc146101a25780634bb278f3146101b7576100f3565b80631515bc2b146100fe5780632c4e722e14610127578063355274ea1461014e5780634019388314610163575b6100fc336102bf565b005b34801561010a57600080fd5b506101136103c6565b604080519115158252519081900360200190f35b34801561013357600080fd5b5061013c6103ce565b60408051918252519081900360200190f35b34801561015a57600080fd5b5061013c6103d4565b34801561016f57600080fd5b5061013c6103da565b34801561018457600080fd5b5061013c6103e0565b34801561019957600080fd5b506101136103e6565b3480156101ae57600080fd5b5061013c610401565b3480156101c357600080fd5b506100fc610407565b3480156101d857600080fd5b506101136104e8565b3480156101ed57600080fd5b506101f66104fc565b604080516001600160a01b039092168252519081900360200190f35b34801561021e57600080fd5b5061011361050b565b34801561023357600080fd5b50610113610518565b34801561024857600080fd5b5061013c610521565b34801561025d57600080fd5b506100fc6004803603602081101561027457600080fd5b50356001600160a01b0316610527565b6100fc6004803603602081101561029a57600080fd5b50356001600160a01b03166102bf565b3480156102b657600080fd5b506101f6610620565b6000805460010190819055346102d5838261062f565b60006102e082610695565b6004549091506102f6908363ffffffff6106b216565b6004556103038482610716565b604080518381526020810183905281516001600160a01b0387169233927f6faf93231a456e552dbc9961f58d9713ee4f2e69d15f1975b050ef0911053a7b929081900390910190a361035584836103c2565b61035d610720565b61036784836103c2565b505060005481146103c25760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b5050565b600754421190565b60035490565b60055490565b60095490565b60045490565b600060065442101580156103fc57506007544211155b905090565b60075490565b60085460ff161561044c57604051600160e51b62461bcd028152600401808060200182810382526027815260200180610b3e6027913960400191505060405180910390fd5b6104546103c6565b6104a85760408051600160e51b62461bcd02815260206004820181905260248201527f46696e616c697a61626c6543726f776473616c653a206e6f7420636c6f736564604482015290519081900360640190fd5b6008805460ff191660011790556104bd610770565b6040517f9270cc390c096600a1c17c44345a1ba689fafd99d97487b10cfccf86cf73183690600090a1565b60006005546104f56103e0565b1015905090565b6002546001600160a01b031690565b60006009546104f56103e0565b60085460ff1690565b60065490565b61052f610518565b61056d57604051600160e51b62461bcd028152600401808060200182810382526022815260200180610bb06022913960400191505060405180910390fd5b61057561050b565b156105b457604051600160e51b62461bcd028152600401808060200182810382526021815260200180610b656021913960400191505060405180910390fd5b600a5460408051600160e01b6351cff8d90281526001600160a01b038481166004830152915191909216916351cff8d991602480830192600092919082900301818387803b15801561060557600080fd5b505af1158015610619573d6000803e3d6000fd5b5050505050565b6001546001600160a01b031690565b6106376103e6565b61068b5760408051600160e51b62461bcd02815260206004820152601860248201527f54696d656443726f776473616c653a206e6f74206f70656e0000000000000000604482015290519081900360640190fd5b6103c282826108c1565b60006106ac6003548361093c90919063ffffffff16565b92915050565b60008282018381101561070f5760408051600160e51b62461bcd02815260206004820152601b60248201527f536166654d6174683a206164646974696f6e206f766572666c6f770000000000604482015290519081900360640190fd5b9392505050565b6103c28282610998565b600a5460408051600160e01b63f340fa0102815233600482015290516001600160a01b039092169163f340fa01913491602480830192600092919082900301818588803b15801561060557600080fd5b61077861050b565b1561085257600a60009054906101000a90046001600160a01b03166001600160a01b03166343d726d66040518163ffffffff1660e01b8152600401600060405180830381600087803b1580156107cd57600080fd5b505af11580156107e1573d6000803e3d6000fd5b50505050600a60009054906101000a90046001600160a01b03166001600160a01b0316639af6549a6040518163ffffffff1660e01b8152600401600060405180830381600087803b15801561083557600080fd5b505af1158015610849573d6000803e3d6000fd5b505050506108bb565b600a60009054906101000a90046001600160a01b03166001600160a01b0316638c52dc416040518163ffffffff1660e01b8152600401600060405180830381600087803b1580156108a257600080fd5b505af11580156108b6573d6000803e3d6000fd5b505050505b6108bf5b565b6108cb8282610a7f565b6005546108e6826108da6103e0565b9063ffffffff6106b216565b11156103c25760408051600160e51b62461bcd02815260206004820152601d60248201527f43617070656443726f776473616c653a20636170206578636565646564000000604482015290519081900360640190fd5b60008261094b575060006106ac565b8282028284828161095857fe5b041461070f57604051600160e51b62461bcd028152600401808060200182810382526021815260200180610b1d6021913960400191505060405180910390fd5b6109a0610620565b6001600160a01b03166340c10f1983836040518363ffffffff1660e01b815260040180836001600160a01b03166001600160a01b0316815260200182815260200192505050602060405180830381600087803b1580156109ff57600080fd5b505af1158015610a13573d6000803e3d6000fd5b505050506040513d6020811015610a2957600080fd5b50516103c25760408051600160e51b62461bcd02815260206004820152601f60248201527f4d696e74656443726f776473616c653a206d696e74696e67206661696c656400604482015290519081900360640190fd5b6001600160a01b038216610ac757604051600160e51b62461bcd02815260040180806020018281038252602a815260200180610b86602a913960400191505060405180910390fd5b806103c25760408051600160e51b62461bcd02815260206004820152601960248201527f43726f776473616c653a20776569416d6f756e74206973203000000000000000604482015290519081900360640190fdfe536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f7746696e616c697a61626c6543726f776473616c653a20616c72656164792066696e616c697a6564526566756e6461626c6543726f776473616c653a20676f616c207265616368656443726f776473616c653a2062656e656669636961727920697320746865207a65726f2061646472657373526566756e6461626c6543726f776473616c653a206e6f742066696e616c697a6564a165627a7a7230582069c79232c13ddca62a1aceabff8db77941426d7260709bfa8c35c2d1304aa49c0029608060405234801561001057600080fd5b50604051602080610b7b8339810180604052602081101561003057600080fd5b5051600080546001600160a01b031916331790819055604080516001600160a01b03929092168252517f4101e71e974f68df5e9730cc223280b41654676bbb052cdcc735c3337e64d2d99181900360200190a16001600160a01b0381166100e2576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602d815260200180610b4e602d913960400191505060405180910390fd5b6002805460ff196001600160a01b039390931661010002610100600160a81b031990911617919091169055610a328061011c6000396000f3fe60806040526004361061009c5760003560e01c80638c52dc41116100645780638c52dc41146101965780639af6549a146101ab578063c19d93fb146101c0578063c6dbdf61146101f9578063e3a9db1a1461020e578063f340fa01146102535761009c565b80632348238c146100a157806338af3eed146100d657806343d726d61461010757806351cff8d91461011c578063685ca1941461014f575b600080fd5b3480156100ad57600080fd5b506100d4600480360360208110156100c457600080fd5b50356001600160a01b0316610279565b005b3480156100e257600080fd5b506100eb610367565b604080516001600160a01b039092168252519081900360200190f35b34801561011357600080fd5b506100d461037b565b34801561012857600080fd5b506100d46004803603602081101561013f57600080fd5b50356001600160a01b0316610450565b34801561015b57600080fd5b506101826004803603602081101561017257600080fd5b50356001600160a01b03166104a3565b604080519115158252519081900360200190f35b3480156101a257600080fd5b506100d46104bf565b3480156101b757600080fd5b506100d4610595565b3480156101cc57600080fd5b506101d5610626565b604051808260028111156101e557fe5b60ff16815260200191505060405180910390f35b34801561020557600080fd5b506100eb61062f565b34801561021a57600080fd5b506102416004803603602081101561023157600080fd5b50356001600160a01b031661063e565b60408051918252519081900360200190f35b6100d46004803603602081101561026957600080fd5b50356001600160a01b0316610659565b6000546001600160a01b031633146102c557604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806109a9602c913960400191505060405180910390fd5b6001600160a01b03811661030d57604051600160e51b62461bcd02815260040180806020018281038252602a81526020018061097f602a913960400191505060405180910390fd5b600080546001600160a01b0319166001600160a01b03838116919091179182905560408051929091168252517f4101e71e974f68df5e9730cc223280b41654676bbb052cdcc735c3337e64d2d9916020908290030190a150565b60025461010090046001600160a01b031690565b6000546001600160a01b031633146103c757604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806109a9602c913960400191505060405180910390fd5b60006002805460ff16908111156103da57fe5b1461041957604051600160e51b62461bcd0281526004018080602001828103825260298152602001806109566029913960400191505060405180910390fd5b6002805460ff1916811790556040517f088672c3a6e342f7cd94a65ba63b79df24a8973927b4d05d803c44bbf787d12f90600090a1565b610459816104a3565b61049757604051600160e51b62461bcd0281526004018080602001828103825260338152602001806109236033913960400191505060405180910390fd5b6104a0816106b4565b50565b600060016002805460ff16908111156104b857fe5b1492915050565b6000546001600160a01b0316331461050b57604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806109a9602c913960400191505060405180910390fd5b60006002805460ff169081111561051e57fe5b1461055d57604051600160e51b62461bcd0281526004018080602001828103825260328152602001806109d56032913960400191505060405180910390fd5b6002805460ff191660011790556040517f599d8e5a83cffb867d051598c4d70e805d59802d8081c1c7d6dffc5b6aca2b8990600090a1565b6002805460ff16818111156105a657fe5b146105e557604051600160e51b62461bcd0281526004018080602001828103825260388152602001806108c06038913960400191505060405180910390fd5b6002546040516001600160a01b036101009092049190911690303180156108fc02916000818181858888f193505050501580156104a0573d6000803e3d6000fd5b60025460ff1690565b6000546001600160a01b031690565b6001600160a01b031660009081526001602052604090205490565b60006002805460ff169081111561066c57fe5b146106ab57604051600160e51b62461bcd02815260040180806020018281038252602b8152602001806108f8602b913960400191505060405180910390fd5b6104a08161078e565b6000546001600160a01b0316331461070057604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806109a9602c913960400191505060405180910390fd5b6001600160a01b038116600081815260016020526040808220805490839055905190929183156108fc02918491818181858888f1935050505015801561074a573d6000803e3d6000fd5b506040805182815290516001600160a01b038416917f7084f5476618d8e60b11ef0d7d3f06914655adb8793e28ff7f018d4c76d505d5919081900360200190a25050565b6000546001600160a01b031633146107da57604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806109a9602c913960400191505060405180910390fd5b6001600160a01b0381166000908152600160205260409020543490610805908263ffffffff61085b16565b6001600160a01b038316600081815260016020908152604091829020939093558051848152905191927f2da466a7b24304f47e87fa2e1e5a81b9831ce54fec19055ce277ca2f39ba42c492918290030190a25050565b6000828201838110156108b85760408051600160e51b62461bcd02815260206004820152601b60248201527f536166654d6174683a206164646974696f6e206f766572666c6f770000000000604482015290519081900360640190fd5b939250505056fe526566756e64457363726f773a2062656e65666963696172792063616e206f6e6c79207769746864726177207768696c6520636c6f736564526566756e64457363726f773a2063616e206f6e6c79206465706f736974207768696c6520616374697665436f6e646974696f6e616c457363726f773a207061796565206973206e6f7420616c6c6f77656420746f207769746864726177526566756e64457363726f773a2063616e206f6e6c7920636c6f7365207768696c65206163746976655365636f6e646172793a206e6577207072696d61727920697320746865207a65726f20616464726573735365636f6e646172793a2063616c6c6572206973206e6f7420746865207072696d617279206163636f756e74526566756e64457363726f773a2063616e206f6e6c7920656e61626c6520726566756e6473207768696c6520616374697665a165627a7a7230582058712fd10606ef193f69390527281cad09943c10207ac9d5c21f1c9298bcce6a0029526566756e64457363726f773a2062656e656669636961727920697320746865207a65726f206164647265737354696d656443726f776473616c653a206f70656e696e672074696d65206973206265666f72652063757272656e742074696d6554696d656443726f776473616c653a206f70656e696e672074696d65206973206e6f74206265666f726520636c6f73696e672074696d6543726f776473616c653a20746f6b656e20697320746865207a65726f206164647265737353616d706c6543726f776453616c653a20676f616c2069732067726561746572207468616e2063617043726f776473616c653a2077616c6c657420697320746865207a65726f2061646472657373";

    public static final String FUNC_HASCLOSED = "hasClosed";

    public static final String FUNC_RATE = "rate";

    public static final String FUNC_CAP = "cap";

    public static final String FUNC_GOAL = "goal";

    public static final String FUNC_WEIRAISED = "weiRaised";

    public static final String FUNC_ISOPEN = "isOpen";

    public static final String FUNC_CLOSINGTIME = "closingTime";

    public static final String FUNC_FINALIZE = "finalize";

    public static final String FUNC_CAPREACHED = "capReached";

    public static final String FUNC_WALLET = "wallet";

    public static final String FUNC_GOALREACHED = "goalReached";

    public static final String FUNC_FINALIZED = "finalized";

    public static final String FUNC_OPENINGTIME = "openingTime";

    public static final String FUNC_CLAIMREFUND = "claimRefund";

    public static final String FUNC_BUYTOKENS = "buyTokens";

    public static final String FUNC_TOKEN = "token";

    public static final Event CROWDSALEFINALIZED_EVENT = new Event("CrowdsaleFinalized", 
            Arrays.<TypeReference<?>>asList());
    ;

    public static final Event TIMEDCROWDSALEEXTENDED_EVENT = new Event("TimedCrowdsaleExtended", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    public static final Event TOKENSPURCHASED_EVENT = new Event("TokensPurchased", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    protected SampleCrowdsale(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected SampleCrowdsale(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<Boolean> hasClosed() {
        final Function function = new Function(FUNC_HASCLOSED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> rate() {
        final Function function = new Function(FUNC_RATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> cap() {
        final Function function = new Function(FUNC_CAP, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> goal() {
        final Function function = new Function(FUNC_GOAL, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> weiRaised() {
        final Function function = new Function(FUNC_WEIRAISED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<Boolean> isOpen() {
        final Function function = new Function(FUNC_ISOPEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> closingTime() {
        final Function function = new Function(FUNC_CLOSINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<Boolean> capReached() {
        final Function function = new Function(FUNC_CAPREACHED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<String> wallet() {
        final Function function = new Function(FUNC_WALLET, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<Boolean> goalReached() {
        final Function function = new Function(FUNC_GOALREACHED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<Boolean> finalized() {
        final Function function = new Function(FUNC_FINALIZED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> openingTime() {
        final Function function = new Function(FUNC_OPENINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> claimRefund(String refundee) {
        final Function function = new Function(
                FUNC_CLAIMREFUND, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(refundee)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> buyTokens(String beneficiary, BigInteger pebValue) {
        final Function function = new Function(
                FUNC_BUYTOKENS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(beneficiary)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, pebValue);
    }

    public RemoteCall<String> token() {
        final Function function = new Function(FUNC_TOKEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public List<CrowdsaleFinalizedEventResponse> getCrowdsaleFinalizedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(CROWDSALEFINALIZED_EVENT, transactionReceipt);
        ArrayList<CrowdsaleFinalizedEventResponse> responses = new ArrayList<CrowdsaleFinalizedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            CrowdsaleFinalizedEventResponse typedResponse = new CrowdsaleFinalizedEventResponse();
            typedResponse.log = eventValues.getLog();
            responses.add(typedResponse);
        }
        return responses;
    }

    public List<TimedCrowdsaleExtendedEventResponse> getTimedCrowdsaleExtendedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TIMEDCROWDSALEEXTENDED_EVENT, transactionReceipt);
        ArrayList<TimedCrowdsaleExtendedEventResponse> responses = new ArrayList<TimedCrowdsaleExtendedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TimedCrowdsaleExtendedEventResponse typedResponse = new TimedCrowdsaleExtendedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.prevClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.newClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public List<TokensPurchasedEventResponse> getTokensPurchasedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TOKENSPURCHASED_EVENT, transactionReceipt);
        ArrayList<TokensPurchasedEventResponse> responses = new ArrayList<TokensPurchasedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TokensPurchasedEventResponse typedResponse = new TokensPurchasedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.purchaser = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.beneficiary = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.amount = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static SampleCrowdsale load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new SampleCrowdsale(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static SampleCrowdsale load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new SampleCrowdsale(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<SampleCrowdsale> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, BigInteger cap, String token, BigInteger goal) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.generated.Uint256(cap), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(goal)));
        return deployRemoteCall(SampleCrowdsale.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<SampleCrowdsale> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, BigInteger cap, String token, BigInteger goal) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.generated.Uint256(cap), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(goal)));
        return deployRemoteCall(SampleCrowdsale.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<SampleCrowdsale> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, BigInteger cap, String token, BigInteger goal) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.generated.Uint256(cap), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(goal)));
        return deployRemoteCall(SampleCrowdsale.class, caverj, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<SampleCrowdsale> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, BigInteger cap, String token, BigInteger goal) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.generated.Uint256(cap), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(goal)));
        return deployRemoteCall(SampleCrowdsale.class, caverj, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    public static class CrowdsaleFinalizedEventResponse {
        public KlayLogs.Log log;
    }

    public static class TimedCrowdsaleExtendedEventResponse {
        public KlayLogs.Log log;

        public BigInteger prevClosingTime;

        public BigInteger newClosingTime;
    }

    public static class TokensPurchasedEventResponse {
        public KlayLogs.Log log;

        public String purchaser;

        public String beneficiary;

        public BigInteger value;

        public BigInteger amount;
    }
}

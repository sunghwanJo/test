package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.util.Arrays;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Bytes4;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class OwnableInterfaceId extends SmartContract {
    private static final String BINARY = "6080604052348015600f57600080fd5b50608a8061001e6000396000f3fe6080604052348015600f57600080fd5b506004361060285760003560e01c80636b9241fc14602d575b600080fd5b60336050565b604080516001600160e01b03199092168252519081900360200190f35b600160e01b63813ae5ed029056fea165627a7a72305820b1fb3806c01f43fcf5b9feadb6d7826401e1ce2529496dbf31c6341cb48b4fce0029";

    public static final String FUNC_GETINTERFACEID = "getInterfaceId";

    protected OwnableInterfaceId(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected OwnableInterfaceId(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<byte[]> getInterfaceId() {
        final Function function = new Function(FUNC_GETINTERFACEID, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bytes4>() {}));
        return executeRemoteCallSingleValueReturn(function, byte[].class);
    }

    public static OwnableInterfaceId load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new OwnableInterfaceId(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static OwnableInterfaceId load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new OwnableInterfaceId(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<OwnableInterfaceId> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(OwnableInterfaceId.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<OwnableInterfaceId> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(OwnableInterfaceId.class, caverj, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<OwnableInterfaceId> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(OwnableInterfaceId.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<OwnableInterfaceId> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(OwnableInterfaceId.class, caverj, transactionManager, contractGasProvider, BINARY, "");
    }
}

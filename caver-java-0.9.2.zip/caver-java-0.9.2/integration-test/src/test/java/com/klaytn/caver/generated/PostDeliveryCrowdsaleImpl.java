package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayLogs;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class PostDeliveryCrowdsaleImpl extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b5060405160a08061118b833981018060405260a081101561003057600080fd5b5080516020820151604083015160608401516080909401516001600055929391929091908484848484826100c557604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f43726f776473616c653a20726174652069732030000000000000000000000000604482015290519081900360640190fd5b6001600160a01b038216610124576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260258152602001806111666025913960400191505060405180910390fd5b6001600160a01b038116610183576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260248152602001806111426024913960400191505060405180910390fd5b600392909255600280546001600160a01b039283166001600160a01b031991821617909155600180549290931691161790554282101561020e576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260338152602001806110d86033913960400191505060405180910390fd5b818111610266576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252603781526020018061110b6037913960400191505060405180910390fd5b60059190915560065560405161027b906102c3565b604051809103906000f080158015610297573d6000803e3d6000fd5b50600880546001600160a01b0319166001600160a01b0392909216919091179055506102d09350505050565b61037e80610d5a83390190565b610a7b806102df6000396000f3fe60806040526004361061009c5760003560e01c80634b6753bc116100645780634b6753bc14610154578063521eb2731461016957806370a082311461019a578063b7a8807c146101cd578063ec8ac4d8146101e2578063fc0c546a146102085761009c565b80631515bc2b146100a75780632c4e722e146100d05780634042b66f146100f757806347535d7b1461010c57806349df728c14610121575b6100a53361021d565b005b3480156100b357600080fd5b506100bc610324565b604080519115158252519081900360200190f35b3480156100dc57600080fd5b506100e561032c565b60408051918252519081900360200190f35b34801561010357600080fd5b506100e5610332565b34801561011857600080fd5b506100bc610338565b34801561012d57600080fd5b506100a56004803603602081101561014457600080fd5b50356001600160a01b0316610353565b34801561016057600080fd5b506100e5610488565b34801561017557600080fd5b5061017e61048e565b604080516001600160a01b039092168252519081900360200190f35b3480156101a657600080fd5b506100e5600480360360208110156101bd57600080fd5b50356001600160a01b031661049d565b3480156101d957600080fd5b506100e56104b8565b6100a5600480360360208110156101f857600080fd5b50356001600160a01b031661021d565b34801561021457600080fd5b5061017e6104be565b60008054600101908190553461023383826104cd565b600061023e82610533565b600454909150610254908363ffffffff61055016565b60045561026184826105b4565b604080518381526020810183905281516001600160a01b0387169233927f6faf93231a456e552dbc9961f58d9713ee4f2e69d15f1975b050ef0911053a7b929081900390910190a36102b38483610320565b6102bb610608565b6102c58483610320565b505060005481146103205760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b5050565b600654421190565b60035490565b60045490565b6000600554421015801561034e57506006544211155b905090565b61035b610324565b61039957604051600160e51b62461bcd028152600401808060200182810382526021815260200180610a056021913960400191505060405180910390fd5b6001600160a01b038116600090815260076020526040902054806103f157604051600160e51b62461bcd0281526004018080602001828103825260388152602001806109826038913960400191505060405180910390fd5b6001600160a01b038083166000908152600760205260408120556008541663beabacc861041c6104be565b6040805163ffffffff841660e01b81526001600160a01b03928316600482015291861660248301526044820185905251606480830192600092919082900301818387803b15801561046c57600080fd5b505af1158015610480573d6000803e3d6000fd5b505050505050565b60065490565b6002546001600160a01b031690565b6001600160a01b031660009081526007602052604090205490565b60055490565b6001546001600160a01b031690565b6104d5610338565b6105295760408051600160e51b62461bcd02815260206004820152601860248201527f54696d656443726f776473616c653a206e6f74206f70656e0000000000000000604482015290519081900360640190fd5b6103208282610644565b600061054a600354836106e190919063ffffffff16565b92915050565b6000828201838110156105ad5760408051600160e51b62461bcd02815260206004820152601b60248201527f536166654d6174683a206164646974696f6e206f766572666c6f770000000000604482015290519081900360640190fd5b9392505050565b6001600160a01b0382166000908152600760205260409020546105dd908263ffffffff61055016565b6001600160a01b0380841660009081526007602052604090209190915560085461032091168261073d565b6002546040516001600160a01b03909116903480156108fc02916000818181858888f19350505050158015610641573d6000803e3d6000fd5b50565b6001600160a01b03821661068c57604051600160e51b62461bcd02815260040180806020018281038252602a8152602001806109db602a913960400191505060405180910390fd5b806103205760408051600160e51b62461bcd02815260206004820152601960248201527f43726f776473616c653a20776569416d6f756e74206973203000000000000000604482015290519081900360640190fd5b6000826106f05750600061054a565b828202828482816106fd57fe5b04146105ad57604051600160e51b62461bcd0281526004018080602001828103825260218152602001806109ba6021913960400191505060405180910390fd5b600154610320906001600160a01b0316838363ffffffff61075a16565b604080516001600160a01b038416602482015260448082018490528251808303909101815260649091019091526020810180516001600160e01b0316600160e01b63a9059cbb021790526107af9084906107b4565b505050565b6107c6826001600160a01b031661097b565b61081a5760408051600160e51b62461bcd02815260206004820152601f60248201527f5361666545524332303a2063616c6c20746f206e6f6e2d636f6e747261637400604482015290519081900360640190fd5b60006060836001600160a01b0316836040518082805190602001908083835b602083106108585780518252601f199092019160209182019101610839565b6001836020036101000a0380198251168184511680821785525050505050509050019150506000604051808303816000865af19150503d80600081146108ba576040519150601f19603f3d011682016040523d82523d6000602084013e6108bf565b606091505b5091509150816109195760408051600160e51b62461bcd02815260206004820181905260248201527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c6564604482015290519081900360640190fd5b8051156109755780806020019051602081101561093557600080fd5b505161097557604051600160e51b62461bcd02815260040180806020018281038252602a815260200180610a26602a913960400191505060405180910390fd5b50505050565b3b15159056fe506f737444656c697665727943726f776473616c653a2062656e6566696369617279206973206e6f742064756520616e7920746f6b656e73536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f7743726f776473616c653a2062656e656669636961727920697320746865207a65726f2061646472657373506f737444656c697665727943726f776473616c653a206e6f7420636c6f7365645361666545524332303a204552433230206f7065726174696f6e20646964206e6f742073756363656564a165627a7a72305820fca4785e4efe9d2a1d44dd7ee6c502501eeaa4b793ca15f706e3d4688f399234002960806040819052600080546001600160a01b0319163317908190556001600160a01b031681527f4101e71e974f68df5e9730cc223280b41654676bbb052cdcc735c3337e64d2d990602090a16103248061005a6000396000f3fe608060405234801561001057600080fd5b50600436106100415760003560e01c80632348238c14610046578063beabacc81461006e578063c6dbdf61146100a4575b600080fd5b61006c6004803603602081101561005c57600080fd5b50356001600160a01b03166100c8565b005b61006c6004803603606081101561008457600080fd5b506001600160a01b038135811691602081013590911690604001356101b6565b6100ac610293565b604080516001600160a01b039092168252519081900360200190f35b6000546001600160a01b0316331461011457604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806102cd602c913960400191505060405180910390fd5b6001600160a01b03811661015c57604051600160e51b62461bcd02815260040180806020018281038252602a8152602001806102a3602a913960400191505060405180910390fd5b600080546001600160a01b0319166001600160a01b03838116919091179182905560408051929091168252517f4101e71e974f68df5e9730cc223280b41654676bbb052cdcc735c3337e64d2d9916020908290030190a150565b6000546001600160a01b0316331461020257604051600160e51b62461bcd02815260040180806020018281038252602c8152602001806102cd602c913960400191505060405180910390fd5b826001600160a01b031663a9059cbb83836040518363ffffffff1660e01b815260040180836001600160a01b03166001600160a01b0316815260200182815260200192505050602060405180830381600087803b15801561026257600080fd5b505af1158015610276573d6000803e3d6000fd5b505050506040513d602081101561028c57600080fd5b5050505050565b6000546001600160a01b03169056fe5365636f6e646172793a206e6577207072696d61727920697320746865207a65726f20616464726573735365636f6e646172793a2063616c6c6572206973206e6f7420746865207072696d617279206163636f756e74a165627a7a723058202376792c4f366d3d66ee139343bda6a3ef368ad4875e51b11abd0b5a01d27d2f002954696d656443726f776473616c653a206f70656e696e672074696d65206973206265666f72652063757272656e742074696d6554696d656443726f776473616c653a206f70656e696e672074696d65206973206e6f74206265666f726520636c6f73696e672074696d6543726f776473616c653a20746f6b656e20697320746865207a65726f206164647265737343726f776473616c653a2077616c6c657420697320746865207a65726f2061646472657373";

    public static final String FUNC_HASCLOSED = "hasClosed";

    public static final String FUNC_RATE = "rate";

    public static final String FUNC_WEIRAISED = "weiRaised";

    public static final String FUNC_ISOPEN = "isOpen";

    public static final String FUNC_WITHDRAWTOKENS = "withdrawTokens";

    public static final String FUNC_CLOSINGTIME = "closingTime";

    public static final String FUNC_WALLET = "wallet";

    public static final String FUNC_BALANCEOF = "balanceOf";

    public static final String FUNC_OPENINGTIME = "openingTime";

    public static final String FUNC_BUYTOKENS = "buyTokens";

    public static final String FUNC_TOKEN = "token";

    public static final Event TIMEDCROWDSALEEXTENDED_EVENT = new Event("TimedCrowdsaleExtended", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    public static final Event TOKENSPURCHASED_EVENT = new Event("TokensPurchased", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    protected PostDeliveryCrowdsaleImpl(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected PostDeliveryCrowdsaleImpl(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<Boolean> hasClosed() {
        final Function function = new Function(FUNC_HASCLOSED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> rate() {
        final Function function = new Function(FUNC_RATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> weiRaised() {
        final Function function = new Function(FUNC_WEIRAISED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<Boolean> isOpen() {
        final Function function = new Function(FUNC_ISOPEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> withdrawTokens(String beneficiary) {
        final Function function = new Function(
                FUNC_WITHDRAWTOKENS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(beneficiary)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> closingTime() {
        final Function function = new Function(FUNC_CLOSINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> wallet() {
        final Function function = new Function(FUNC_WALLET, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> balanceOf(String account) {
        final Function function = new Function(FUNC_BALANCEOF, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(account)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> openingTime() {
        final Function function = new Function(FUNC_OPENINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> buyTokens(String beneficiary, BigInteger pebValue) {
        final Function function = new Function(
                FUNC_BUYTOKENS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(beneficiary)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, pebValue);
    }

    public RemoteCall<String> token() {
        final Function function = new Function(FUNC_TOKEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public List<TimedCrowdsaleExtendedEventResponse> getTimedCrowdsaleExtendedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TIMEDCROWDSALEEXTENDED_EVENT, transactionReceipt);
        ArrayList<TimedCrowdsaleExtendedEventResponse> responses = new ArrayList<TimedCrowdsaleExtendedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TimedCrowdsaleExtendedEventResponse typedResponse = new TimedCrowdsaleExtendedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.prevClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.newClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public List<TokensPurchasedEventResponse> getTokensPurchasedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TOKENSPURCHASED_EVENT, transactionReceipt);
        ArrayList<TokensPurchasedEventResponse> responses = new ArrayList<TokensPurchasedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TokensPurchasedEventResponse typedResponse = new TokensPurchasedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.purchaser = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.beneficiary = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.amount = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static PostDeliveryCrowdsaleImpl load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new PostDeliveryCrowdsaleImpl(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static PostDeliveryCrowdsaleImpl load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new PostDeliveryCrowdsaleImpl(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<PostDeliveryCrowdsaleImpl> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, String token) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token)));
        return deployRemoteCall(PostDeliveryCrowdsaleImpl.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<PostDeliveryCrowdsaleImpl> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, String token) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token)));
        return deployRemoteCall(PostDeliveryCrowdsaleImpl.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<PostDeliveryCrowdsaleImpl> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, String token) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token)));
        return deployRemoteCall(PostDeliveryCrowdsaleImpl.class, caverj, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<PostDeliveryCrowdsaleImpl> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, BigInteger rate, String wallet, String token) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(rate), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token)));
        return deployRemoteCall(PostDeliveryCrowdsaleImpl.class, caverj, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    public static class TimedCrowdsaleExtendedEventResponse {
        public KlayLogs.Log log;

        public BigInteger prevClosingTime;

        public BigInteger newClosingTime;
    }

    public static class TokensPurchasedEventResponse {
        public KlayLogs.Log log;

        public String purchaser;

        public String beneficiary;

        public BigInteger value;

        public BigInteger amount;
    }
}

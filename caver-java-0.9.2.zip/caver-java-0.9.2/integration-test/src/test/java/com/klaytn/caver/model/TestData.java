// Modifications copyright 2019 The caver-java Authors
// Copyright 2016 Conor Svensson

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.model;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import org.web3j.protocol.ObjectMapperFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestData {

    private String tcID;
    private String tcName;
    private List<AbstractTest> test;

    public String getTcID() {
        return tcID;
    }

    public String getTcName() {
        return tcName;
    }

    public List<AbstractTest> getTest() {
        return test;
    }

    @JsonDeserialize(using = ResponseDeserialiser.class)
    public void setTest(List<AbstractTest> test) {
        this.test = test;
    }

    public static class ResponseDeserialiser extends JsonDeserializer<List<AbstractTest>> {

        private ObjectMapper objectMapper = ObjectMapperFactory.getObjectMapper();

        @Override
        public List<AbstractTest> deserialize(
                JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
            JsonNode node = jsonParser.getCodec().readTree(jsonParser);
            Iterator<JsonNode> iterator = node.iterator();

            List<AbstractTest> abstractTests = new ArrayList<>();
            while(iterator.hasNext()) {
                JsonNode nextNode = iterator.next();
                if (nextNode.has("tx")) {
                    abstractTests.add(objectMapper.readValue(nextNode.toString(), Transaction.class));
                } else if (nextNode.has("api")) {
                    abstractTests.add(objectMapper.readValue(nextNode.toString(), API.class));
                }
            }
            return abstractTests;
        }
    }
}

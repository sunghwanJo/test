package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class ReentrancyGuard extends SmartContract {
    private static final String BINARY = "";

    protected ReentrancyGuard(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected ReentrancyGuard(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static ReentrancyGuard load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new ReentrancyGuard(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static ReentrancyGuard load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new ReentrancyGuard(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<ReentrancyGuard> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyGuard.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyGuard> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyGuard.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyGuard> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyGuard.class, caverj, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyGuard> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyGuard.class, caverj, transactionManager, contractGasProvider, BINARY, "");
    }
}

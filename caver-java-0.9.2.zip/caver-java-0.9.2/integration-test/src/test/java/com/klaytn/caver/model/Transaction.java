// Modifications copyright 2019 The caver-java Authors
// Copyright 2016 Conor Svensson

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.Bytes32;
import com.klaytn.caver.methods.response.KlayAccountKey;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.manager.PollingTransactionReceiptProcessor;
import com.klaytn.caver.tx.model.KlayRawTransaction;
import com.klaytn.caver.tx.model.SmartContractDeployTransaction;
import com.klaytn.caver.tx.model.ValueTransferTransaction;
import com.klaytn.caver.tx.type.TxType;
import com.klaytn.caver.tx.type.TxTypeAccountCreation;
import com.klaytn.caver.tx.type.TxTypeLegacyTransaction;
import org.web3j.crypto.Keys;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.utils.Numeric;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Random;

import static org.junit.Assert.assertEquals;

public class Transaction extends AbstractTest {

    private InnerTransaction tx;
    private Expected expected;

    public InnerTransaction getTx() {
        return tx;
    }

    public Expected getExpected() {
        return expected;
    }

    public Expected.Receipt getReceipt() {
        return expected.getReceipt();
    }

    public class InnerTransaction {
        private String type;
        private int chainId;
        private BigInteger nonce;
        private Credentials from;
        private String to;
        private String value;
        private String gas;
        private BigInteger gasPrice;
        private String data;
        private String memo;
        private String v;
        private String r;
        private String s;
        private BigInteger codeFormat;
        private KlayAccountKey.AccountKeyValue accountKey;


        public int getChainId() {
            if (chainId == 0) return DEFAULT_CHAIN_ID;
            return chainId;
        }

        public BigInteger getNonce() throws IOException {
            if (nonce != null) return nonce;
            return caverj.klay()
                    .getTransactionCount(sender.getAddress(), DefaultBlockParameterName.PENDING)
                    .send().getValue();
        }

        public void setGasPrice(String gasPrice) {
            this.gasPrice = Numeric.toBigInt(gasPrice);
        }

        public BigInteger getGasPrice() {
            if (gasPrice == null) {
                return DEFAULT_GAS_PRICE;
            }
            return gasPrice;
        }

        public String getType() {
            return type;
        }


        public KlayCredentials getFrom() {
            if (from == null) return sender;
            return KlayCredentials.create(
                    from.getPrivateKey(),
                    from.getAddress()
            );
        }

        public String getTo() throws Exception {
            if (to == null) return "";
            if (to.equals("random")) return Keys.getAddress(Keys.createEcKeyPair());
            if (to.equals("env.sender")) return sender.getAddress();
            if (to.equals("hrm.random")) return "colin" + new Random().nextInt(1000) + ".klaytn";
            return to;
        }

        public BigInteger getValue() {
            if (value == null) return BigInteger.ZERO;
            return Numeric.toBigInt(value);
        }

        public BigInteger getGas() {
            return new BigDecimal(gas).toBigInteger();
        }

        public String getData() {
            return data;
        }

        public byte[] getPayload() {
            if (data == null) return new byte[]{};
            return Numeric.hexStringToByteArray(data);
        }

        public String getMemo() {
            return memo;
        }

        public String getV() {
            return v;
        }

        public String getR() {
            return r;
        }

        public String getS() {
            return s;
        }

        public BigInteger getCodeFormat() {
            return codeFormat;
        }

        public KlayAccountKey.AccountKeyValue getAccountKey() {
            return accountKey;
        }

        @JsonDeserialize(using = KlayAccountKey.AccountKeyDeserializer.class)
        public void setAccountKey(KlayAccountKey.AccountKeyValue accountKey) {
            this.accountKey = accountKey;
        }
    }

    @Override
    public void execute() throws Exception {
        String type = getTx().getType();
        TxType transaction = getTransaction(type);

        assert transaction != null;
        KlayRawTransaction signatureData = transaction.sign(getTx().getFrom(), getTx().getChainId());

        String signedTransaction = manipulateSignature(signatureData);

        Bytes32 response = caverj.klay()
                .sendSignedTransaction(signedTransaction)
                .send();

        if (getExpected() == null) return;
        if (!getExpected().isStatus()) {
            assertEquals(response.getError().getMessage(), getExpected().getErrorString());
            return;
        }

        KlayTransactionReceipt.TransactionReceipt receipt
                = new PollingTransactionReceiptProcessor(caverj, 1000, 15)
                .waitForTransactionReceipt(response.getResult());

        if (getReceipt() != null) {
            checkReceipt(receipt);
        }
    }

    private void checkReceipt(KlayTransactionReceipt.TransactionReceipt receipt) {
        if (getReceipt().getStatus() != null) {
            assertEquals(Boolean.valueOf(getReceipt().getStatus()), receipt.getStatus().equals("0x1"));
        }
        if (getReceipt().isCheckContractAddress() != null) {
            assertEquals(getReceipt().isCheckContractAddress(), receipt.getContractAddress());
        }
        if (getReceipt().getTxError() != null) {
            assertEquals(getReceipt().getTxError(), receipt.getTxError());
        }
    }

    private String manipulateSignature(KlayRawTransaction signatureData) {
        String signedTransaction = signatureData.getValueAsString();
        if (getTx().getV() != null) {
            String originV = Numeric.toHexStringNoPrefix(signatureData.getSignatureData().getV());
            signedTransaction = signedTransaction.replace(originV, Numeric.cleanHexPrefix(getTx().getV()));
        }
        if (getTx().getR() != null) {
            String originR = Numeric.toHexStringNoPrefix(signatureData.getSignatureData().getR());
            signedTransaction = signedTransaction.replace(originR, Numeric.cleanHexPrefix(getTx().getR()));
        }
        if (getTx().getS() != null) {
            String originS = Numeric.toHexStringNoPrefix(signatureData.getSignatureData().getS());
            signedTransaction = signedTransaction.replace(originS, Numeric.cleanHexPrefix(getTx().getS()));
        }
        return signedTransaction;
    }

    private TxType getTransaction(String type) throws Exception {
        TxType transaction = null;
        if (type.equals(TxType.Type.LEGACY.name())) {
            transaction = TxTypeLegacyTransaction.createTransaction(
                    getTx().getNonce(),
                    getTx().getGasPrice(),
                    getTx().getGas(),
                    getTx().getTo(),
                    getTx().getValue(),
                    getTx().getData()
            );
        } else if (type.equals(TxType.Type.VALUE_TRANSFER.name()) || type.equals(TxType.Type.VALUE_TRANSFER_MEMO.name())) {
            ValueTransferTransaction mayTransaction = ValueTransferTransaction.create(
                    sender.getAddress(),
                    getTx().getTo(),
                    getTx().getValue(),
                    getTx().getGas())
                    .nonce(getTx().getNonce())
                    .gasPrice(getTx().getGasPrice());
            if (getTx().memo != null) mayTransaction.memo(getTx().getMemo());
            return mayTransaction.build();
        } else if (type.equals(TxType.Type.ACCOUNT_CREATION.name())) {
            transaction = TxTypeAccountCreation.createTransaction(
                    getTx().getNonce(),
                    getTx().getGasPrice(),
                    getTx().getGas(),
                    getTx().getTo(),
                    getTx().getValue(),
                    sender.getAddress(),
                    getTx().getAccountKey().getKey());
        } else if (type.equals(TxType.Type.SMART_CONTRACT_DEPLOY.name())) {
            transaction = SmartContractDeployTransaction.create(
                    sender.getAddress(),
                    getTx().getTo(),
                    getTx().getValue(),
                    getTx().getPayload(),
                    getTx().getGas(),
                    getTx().getCodeFormat())
                    .nonce(getTx().getNonce())
                    .gasPrice(getTx().getGasPrice())
                    .build();
        }
        return transaction;
    }

}

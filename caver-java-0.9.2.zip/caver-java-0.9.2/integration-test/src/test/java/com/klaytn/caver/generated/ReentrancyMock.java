package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class ReentrancyMock extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b50600160008181559055610450806100296000396000f3fe608060405234801561001057600080fd5b50600436106100575760003560e01c8063083b27321461005c57806361bc221a146100665780638c5344fa1461008057806396ffa6901461009d578063b672ad8b146100ba575b600080fd5b6100646100e0565b005b61006e61014f565b60408051918252519081900360200190f35b6100646004803603602081101561009657600080fd5b5035610155565b610064600480360360208110156100b357600080fd5b50356102fe565b610064600480360360208110156100d057600080fd5b50356001600160a01b0316610323565b60008054600101908190556100f361041a565b600054811461014c5760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b50565b60015481565b600080546001019081905581156102a15761016e61041a565b60408051600019840160248083019190915282518083039091018152604490910182526020810180516001600160e01b0316600160e11b634629a27d0217815291518151600093309392918291908083835b602083106101df5780518252601f1990920191602091820191016101c0565b6001836020036101000a0380198251168184511680821785525050505050509050019150506000604051808303816000865af19150503d8060008114610241576040519150601f19603f3d011682016040523d82523d6000602084013e610246565b606091505b505090508061029f5760408051600160e51b62461bcd02815260206004820152601b60248201527f5265656e7472616e63794d6f636b3a206661696c65642063616c6c0000000000604482015290519081900360640190fd5b505b60005481146102fa5760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b5050565b600080546001019081905581156102a15761031761041a565b6102a1600183036102fe565b600080546001019081905561033661041a565b60408051600160b01b6963616c6c6261636b2829028152815190819003600a018120600160e01b630a2df1ed0282526001600160e01b03198116600483015291516001600160a01b03851691630a2df1ed91602480830192600092919082900301818387803b1580156103a857600080fd5b505af11580156103bc573d6000803e3d6000fd5b505050505060005481146102fa5760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b600180548101905556fea165627a7a723058202a05c4c4e4ae118caaae957b5a0e1ac16f79cc5cd2d9d860fc4903013b77790d0029";

    public static final String FUNC_CALLBACK = "callback";

    public static final String FUNC_COUNTER = "counter";

    public static final String FUNC_COUNTTHISRECURSIVE = "countThisRecursive";

    public static final String FUNC_COUNTLOCALRECURSIVE = "countLocalRecursive";

    public static final String FUNC_COUNTANDCALL = "countAndCall";

    protected ReentrancyMock(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected ReentrancyMock(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> callback() {
        final Function function = new Function(
                FUNC_CALLBACK, 
                Arrays.<Type>asList(), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<BigInteger> counter() {
        final Function function = new Function(FUNC_COUNTER, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> countThisRecursive(BigInteger n) {
        final Function function = new Function(
                FUNC_COUNTTHISRECURSIVE, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(n)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> countLocalRecursive(BigInteger n) {
        final Function function = new Function(
                FUNC_COUNTLOCALRECURSIVE, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(n)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> countAndCall(String attacker) {
        final Function function = new Function(
                FUNC_COUNTANDCALL, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(attacker)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public static ReentrancyMock load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new ReentrancyMock(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static ReentrancyMock load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new ReentrancyMock(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<ReentrancyMock> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyMock.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyMock> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyMock.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyMock> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyMock.class, caverj, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<ReentrancyMock> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(ReentrancyMock.class, caverj, transactionManager, contractGasProvider, BINARY, "");
    }
}

package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.util.Arrays;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Bytes32;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class IERC1820Implementer extends SmartContract {
    private static final String BINARY = "";

    public static final String FUNC_CANIMPLEMENTINTERFACEFORADDRESS = "canImplementInterfaceForAddress";

    protected IERC1820Implementer(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected IERC1820Implementer(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<byte[]> canImplementInterfaceForAddress(byte[] interfaceHash, String account) {
        final Function function = new Function(FUNC_CANIMPLEMENTINTERFACEFORADDRESS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Bytes32(interfaceHash), 
                new org.web3j.abi.datatypes.Address(account)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bytes32>() {}));
        return executeRemoteCallSingleValueReturn(function, byte[].class);
    }

    public static IERC1820Implementer load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new IERC1820Implementer(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static IERC1820Implementer load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new IERC1820Implementer(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<IERC1820Implementer> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(IERC1820Implementer.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<IERC1820Implementer> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(IERC1820Implementer.class, caverj, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<IERC1820Implementer> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(IERC1820Implementer.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<IERC1820Implementer> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(IERC1820Implementer.class, caverj, transactionManager, contractGasProvider, BINARY, "");
    }
}

package com.klaytn.caver.generated;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayLogs;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.SmartContract;
import com.klaytn.caver.tx.manager.TransactionManager;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.FunctionEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Address;
import org.web3j.abi.datatypes.Bool;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.generated.Uint256;
import org.web3j.protocol.core.RemoteCall;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated smart contract code.
 * <p><strong>Do not modify!</strong>
 */
public class IncreasingPriceCrowdsaleImpl extends SmartContract {
    private static final String BINARY = "608060405234801561001057600080fd5b5060405160c080610eba833981018060405260c081101561003057600080fd5b508051602082015160408301516060840151608085015160a0909501516001600055939492939192909181818787838888826100cd57604080517f08c379a000000000000000000000000000000000000000000000000000000000815260206004820152601460248201527f43726f776473616c653a20726174652069732030000000000000000000000000604482015290519081900360640190fd5b6001600160a01b03821661012c576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526025815260200180610e956025913960400191505060405180910390fd5b6001600160a01b03811661018b576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526024815260200180610e716024913960400191505060405180910390fd5b600392909255600280546001600160a01b039283166001600160a01b0319918216179091556001805492909316911617905542821015610216576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526033815260200180610d996033913960400191505060405180910390fd5b81811161026e576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526037815260200180610e116037913960400191505060405180910390fd5b600591909155600655806102cd576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526029815260200180610e486029913960400191505060405180910390fd5b808211610325576040517f08c379a0000000000000000000000000000000000000000000000000000000008152600401808060200182810382526045815260200180610dcc6045913960600191505060405180910390fd5b600791909155600855505050505050610a56806103436000396000f3fe6080604052600436106100a75760003560e01c8063521eb27311610064578063521eb273146101565780639e51051f14610187578063b7a8807c1461019c578063ec8ac4d8146101b1578063f7fb07b0146101d7578063fc0c546a146101ec576100a7565b80631515bc2b146100b257806321106109146100db5780632c4e722e146101025780634042b66f1461011757806347535d7b1461012c5780634b6753bc14610141575b6100b033610201565b005b3480156100be57600080fd5b506100c7610308565b604080519115158252519081900360200190f35b3480156100e757600080fd5b506100f0610311565b60408051918252519081900360200190f35b34801561010e57600080fd5b506100f0610317565b34801561012357600080fd5b506100f0610353565b34801561013857600080fd5b506100c7610359565b34801561014d57600080fd5b506100f0610374565b34801561016257600080fd5b5061016b61037a565b604080516001600160a01b039092168252519081900360200190f35b34801561019357600080fd5b506100f0610389565b3480156101a857600080fd5b506100f061038f565b6100b0600480360360208110156101c757600080fd5b50356001600160a01b0316610201565b3480156101e357600080fd5b506100f0610395565b3480156101f857600080fd5b5061016b61043f565b600080546001019081905534610217838261044e565b6000610222826104b4565b600454909150610238908363ffffffff6104d816565b600455610245848261053e565b604080518381526020810183905281516001600160a01b0387169233927f6faf93231a456e552dbc9961f58d9713ee4f2e69d15f1975b050ef0911053a7b929081900390910190a36102978483610304565b61029f610548565b6102a98483610304565b505060005481146103045760408051600160e51b62461bcd02815260206004820152601f60248201527f5265656e7472616e637947756172643a207265656e7472616e742063616c6c00604482015290519081900360640190fd5b5050565b60065442115b90565b60085490565b6000604051600160e51b62461bcd02815260040180806020018281038252602781526020018061098f6027913960400191505060405180910390fd5b60045490565b6000600554421015801561036f57506006544211155b905090565b60065490565b6002546001600160a01b031690565b60075490565b60055490565b600061039f610359565b6103ab5750600061030e565b60006103c56103b861038f565b429063ffffffff61058416565b905060006103e86103d461038f565b6103dc610374565b9063ffffffff61058416565b9050600061040360085460075461058490919063ffffffff16565b90506104376104288361041c868563ffffffff6105e416565b9063ffffffff61064016565b6007549063ffffffff61058416565b935050505090565b6001546001600160a01b031690565b610456610359565b6104aa5760408051600160e51b62461bcd02815260206004820152601860248201527f54696d656443726f776473616c653a206e6f74206f70656e0000000000000000604482015290519081900360640190fd5b61030482826106ad565b6000806104bf610395565b90506104d1818463ffffffff6105e416565b9392505050565b6000828201838110156105355760408051600160e51b62461bcd02815260206004820152601b60248201527f536166654d6174683a206164646974696f6e206f766572666c6f770000000000604482015290519081900360640190fd5b90505b92915050565b610304828261074a565b6002546040516001600160a01b03909116903480156108fc02916000818181858888f19350505050158015610581573d6000803e3d6000fd5b50565b6000828211156105de5760408051600160e51b62461bcd02815260206004820152601e60248201527f536166654d6174683a207375627472616374696f6e206f766572666c6f770000604482015290519081900360640190fd5b50900390565b6000826105f357506000610538565b8282028284828161060057fe5b041461053557604051600160e51b62461bcd0281526004018080602001828103825260218152602001806109b66021913960400191505060405180910390fd5b60008082116106995760408051600160e51b62461bcd02815260206004820152601a60248201527f536166654d6174683a206469766973696f6e206279207a65726f000000000000604482015290519081900360640190fd5b60008284816106a457fe5b04949350505050565b6001600160a01b0382166106f557604051600160e51b62461bcd02815260040180806020018281038252602a8152602001806109d7602a913960400191505060405180910390fd5b806103045760408051600160e51b62461bcd02815260206004820152601960248201527f43726f776473616c653a20776569416d6f756e74206973203000000000000000604482015290519081900360640190fd5b600154610304906001600160a01b0316838363ffffffff61076716565b604080516001600160a01b038416602482015260448082018490528251808303909101815260649091019091526020810180516001600160e01b0316600160e01b63a9059cbb021790526107bc9084906107c1565b505050565b6107d3826001600160a01b0316610988565b6108275760408051600160e51b62461bcd02815260206004820152601f60248201527f5361666545524332303a2063616c6c20746f206e6f6e2d636f6e747261637400604482015290519081900360640190fd5b60006060836001600160a01b0316836040518082805190602001908083835b602083106108655780518252601f199092019160209182019101610846565b6001836020036101000a0380198251168184511680821785525050505050509050019150506000604051808303816000865af19150503d80600081146108c7576040519150601f19603f3d011682016040523d82523d6000602084013e6108cc565b606091505b5091509150816109265760408051600160e51b62461bcd02815260206004820181905260248201527f5361666545524332303a206c6f772d6c6576656c2063616c6c206661696c6564604482015290519081900360640190fd5b8051156109825780806020019051602081101561094257600080fd5b505161098257604051600160e51b62461bcd02815260040180806020018281038252602a815260200180610a01602a913960400191505060405180910390fd5b50505050565b3b15159056fe496e6372656173696e67507269636543726f776473616c653a207261746528292063616c6c6564536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f7743726f776473616c653a2062656e656669636961727920697320746865207a65726f20616464726573735361666545524332303a204552433230206f7065726174696f6e20646964206e6f742073756363656564a165627a7a723058208e0b72d15a4a855f235c5be99746d8970bb3793e2735948773b1e4b2a2bf45d7002954696d656443726f776473616c653a206f70656e696e672074696d65206973206265666f72652063757272656e742074696d65496e6372656173696e67507269636543726f776473616c653a20696e697469616c2072617465206973206e6f742067726561746572207468616e2066696e616c207261746554696d656443726f776473616c653a206f70656e696e672074696d65206973206e6f74206265666f726520636c6f73696e672074696d65496e6372656173696e67507269636543726f776473616c653a2066696e616c2072617465206973203043726f776473616c653a20746f6b656e20697320746865207a65726f206164647265737343726f776473616c653a2077616c6c657420697320746865207a65726f2061646472657373";

    public static final String FUNC_HASCLOSED = "hasClosed";

    public static final String FUNC_FINALRATE = "finalRate";

    public static final String FUNC_RATE = "rate";

    public static final String FUNC_WEIRAISED = "weiRaised";

    public static final String FUNC_ISOPEN = "isOpen";

    public static final String FUNC_CLOSINGTIME = "closingTime";

    public static final String FUNC_WALLET = "wallet";

    public static final String FUNC_INITIALRATE = "initialRate";

    public static final String FUNC_OPENINGTIME = "openingTime";

    public static final String FUNC_BUYTOKENS = "buyTokens";

    public static final String FUNC_GETCURRENTRATE = "getCurrentRate";

    public static final String FUNC_TOKEN = "token";

    public static final Event TIMEDCROWDSALEEXTENDED_EVENT = new Event("TimedCrowdsaleExtended", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    public static final Event TOKENSPURCHASED_EVENT = new Event("TokensPurchased", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Address>(true) {}, new TypeReference<Address>(true) {}, new TypeReference<Uint256>() {}, new TypeReference<Uint256>() {}));
    ;

    protected IncreasingPriceCrowdsaleImpl(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, credentials, contractGasProvider);
    }

    protected IncreasingPriceCrowdsaleImpl(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public RemoteCall<Boolean> hasClosed() {
        final Function function = new Function(FUNC_HASCLOSED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> finalRate() {
        final Function function = new Function(FUNC_FINALRATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> rate() {
        final Function function = new Function(FUNC_RATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> weiRaised() {
        final Function function = new Function(FUNC_WEIRAISED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<Boolean> isOpen() {
        final Function function = new Function(FUNC_ISOPEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Bool>() {}));
        return executeRemoteCallSingleValueReturn(function, Boolean.class);
    }

    public RemoteCall<BigInteger> closingTime() {
        final Function function = new Function(FUNC_CLOSINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> wallet() {
        final Function function = new Function(FUNC_WALLET, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<BigInteger> initialRate() {
        final Function function = new Function(FUNC_INITIALRATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<BigInteger> openingTime() {
        final Function function = new Function(FUNC_OPENINGTIME, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<KlayTransactionReceipt.TransactionReceipt> buyTokens(String beneficiary, BigInteger pebValue) {
        final Function function = new Function(
                FUNC_BUYTOKENS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Address(beneficiary)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function, pebValue);
    }

    public RemoteCall<BigInteger> getCurrentRate() {
        final Function function = new Function(FUNC_GETCURRENTRATE, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Uint256>() {}));
        return executeRemoteCallSingleValueReturn(function, BigInteger.class);
    }

    public RemoteCall<String> token() {
        final Function function = new Function(FUNC_TOKEN, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Address>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public List<TimedCrowdsaleExtendedEventResponse> getTimedCrowdsaleExtendedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TIMEDCROWDSALEEXTENDED_EVENT, transactionReceipt);
        ArrayList<TimedCrowdsaleExtendedEventResponse> responses = new ArrayList<TimedCrowdsaleExtendedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TimedCrowdsaleExtendedEventResponse typedResponse = new TimedCrowdsaleExtendedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.prevClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.newClosingTime = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public List<TokensPurchasedEventResponse> getTokensPurchasedEvents(KlayTransactionReceipt.TransactionReceipt transactionReceipt) {
        List<SmartContract.EventValuesWithLog> valueList = extractEventParametersWithLog(TOKENSPURCHASED_EVENT, transactionReceipt);
        ArrayList<TokensPurchasedEventResponse> responses = new ArrayList<TokensPurchasedEventResponse>(valueList.size());
        for (SmartContract.EventValuesWithLog eventValues : valueList) {
            TokensPurchasedEventResponse typedResponse = new TokensPurchasedEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.purchaser = (String) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.beneficiary = (String) eventValues.getIndexedValues().get(1).getValue();
            typedResponse.value = (BigInteger) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.amount = (BigInteger) eventValues.getNonIndexedValues().get(1).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public static IncreasingPriceCrowdsaleImpl load(String contractAddress, Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider) {
        return new IncreasingPriceCrowdsaleImpl(contractAddress, caverj, credentials, contractGasProvider);
    }

    public static IncreasingPriceCrowdsaleImpl load(String contractAddress, Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new IncreasingPriceCrowdsaleImpl(contractAddress, caverj, transactionManager, contractGasProvider);
    }

    public static RemoteCall<IncreasingPriceCrowdsaleImpl> deploy(Caver caverj, KlayCredentials credentials, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, String wallet, String token, BigInteger initialRate, BigInteger finalRate) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(initialRate), 
                new org.web3j.abi.datatypes.generated.Uint256(finalRate)));
        return deployRemoteCall(IncreasingPriceCrowdsaleImpl.class, caverj, credentials, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<IncreasingPriceCrowdsaleImpl> deploy(Caver caverj, TransactionManager transactionManager, String contractAddress, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, String wallet, String token, BigInteger initialRate, BigInteger finalRate) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(initialRate), 
                new org.web3j.abi.datatypes.generated.Uint256(finalRate)));
        return deployRemoteCall(IncreasingPriceCrowdsaleImpl.class, caverj, transactionManager, contractAddress, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<IncreasingPriceCrowdsaleImpl> deploy(Caver caverj, KlayCredentials credentials, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, String wallet, String token, BigInteger initialRate, BigInteger finalRate) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(initialRate), 
                new org.web3j.abi.datatypes.generated.Uint256(finalRate)));
        return deployRemoteCall(IncreasingPriceCrowdsaleImpl.class, caverj, credentials, contractGasProvider, BINARY, encodedConstructor);
    }

    public static RemoteCall<IncreasingPriceCrowdsaleImpl> deploy(Caver caverj, TransactionManager transactionManager, ContractGasProvider contractGasProvider, BigInteger openingTime, BigInteger closingTime, String wallet, String token, BigInteger initialRate, BigInteger finalRate) {
        String encodedConstructor = FunctionEncoder.encodeConstructor(Arrays.<Type>asList(new org.web3j.abi.datatypes.generated.Uint256(openingTime), 
                new org.web3j.abi.datatypes.generated.Uint256(closingTime), 
                new org.web3j.abi.datatypes.Address(wallet), 
                new org.web3j.abi.datatypes.Address(token), 
                new org.web3j.abi.datatypes.generated.Uint256(initialRate), 
                new org.web3j.abi.datatypes.generated.Uint256(finalRate)));
        return deployRemoteCall(IncreasingPriceCrowdsaleImpl.class, caverj, transactionManager, contractGasProvider, BINARY, encodedConstructor);
    }

    public static class TimedCrowdsaleExtendedEventResponse {
        public KlayLogs.Log log;

        public BigInteger prevClosingTime;

        public BigInteger newClosingTime;
    }

    public static class TokensPurchasedEventResponse {
        public KlayLogs.Log log;

        public String purchaser;

        public String beneficiary;

        public BigInteger value;

        public BigInteger amount;
    }
}

// Copyright 2019 The caver-java Authors

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.feature;

import com.klaytn.caver.utils.HumanReadableAddressUtils;
import junit.framework.TestCase;
import org.junit.Test;

import static junit.framework.TestCase.*;

public class HumanReadableAddressTest {

    @Test
    public void testCommonRawAddress() {
        String address = "0x90B3E9A3770481345A7F17f22f16D020Bccfd33e";
        TestCase.assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testAbnormalRawAddress() {
        String address = "0x90B3E9A37702f16D020Bccfd33";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testNormalHumanReadableAddress() {
        String address = "luman.klaytn";
        assertTrue(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testNormalHumanReadableAddress2() {
        String address5 = "lumanluman.klaytn";
        assertTrue(HumanReadableAddressUtils.isHumanReadableAddress(address5));
    }

    @Test
    public void testNoIdentifier() {
        String address = "brandon";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testNoIdentifier2() {
        String address = "a.";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testLengthExceed() {
        String address = "lumanlumanlumanlumanluman.klaytn";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testLengthTooShort() {
        String address = "a.klaytn";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testStartedWithNumber() {
        String address = "5blahbl";
        assertFalse(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testWithCapitalLetter() {
        String address = "WAYNE.klaytn";
        assertTrue(HumanReadableAddressUtils.isHumanReadableAddress(address));
    }

    @Test
    public void testToRawAddress() {
        String address = "luman.klaytn";
        assertEquals("0x6c756d616e2e6b6c6179746e0000000000000000",
                HumanReadableAddressUtils.toRawAddress(address));
    }

    @Test
    public void testToRawAddress2() {
        String address = "WAYNE.klaytn";
        assertEquals("0x5741594e452e6b6c6179746e0000000000000000",
                HumanReadableAddressUtils.toRawAddress(address));
    }
}

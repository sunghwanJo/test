// Copyright 2019 The caver-java Authors

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.scenario;

import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.tx.account.AccountKey;
import com.klaytn.caver.tx.account.AccountKeyPublic;
import com.klaytn.caver.tx.account.AccountKeyRoleBased;
import com.klaytn.caver.tx.account.AccountKeyWeightedMultiSig;
import com.klaytn.caver.tx.manager.PollingTransactionReceiptProcessor;
import com.klaytn.caver.tx.manager.TransactionManager;
import com.klaytn.caver.tx.model.AccountCreationTransaction;
import com.klaytn.caver.utils.Convert;
import org.junit.Test;
import org.web3j.crypto.ECKeyPair;
import org.web3j.crypto.Keys;

import java.math.BigInteger;
import java.util.Arrays;

import static com.klaytn.caver.base.Accounts.BRANDON;
import static org.junit.Assert.assertEquals;

public class AccountKeyIT extends Scenario {

    KlayCredentials credentials1, credentials2, credentials3;

    @Test
    public void AccountKeyRolebased() throws Exception {
        KlayCredentials rolebased = KlayCredentials.create(Keys.createEcKeyPair());
        TransactionManager transactionManager = new TransactionManager.Builder(caver, BRANDON)
                .setTransactionReceiptProcessor(new PollingTransactionReceiptProcessor(caver, 1000, 15))
                .build();
        setUpAccount(transactionManager);

        AccountCreationTransaction accountCreationTransaction = AccountCreationTransaction.create(
                BRANDON.getAddress(),
                rolebased.getAddress(),
                Convert.toPeb("0.2", Convert.Unit.KLAY).toBigInteger(),
                GAS_LIMIT,
                createRolebased()
        );
        KlayTransactionReceipt.TransactionReceipt transactionReceipt = transactionManager.executeTransaction(accountCreationTransaction);
        assertEquals("0x1", transactionReceipt.getStatus());
    }

    private AccountKey createRolebased() {
        return AccountKeyRoleBased.create(Arrays.asList(
                AccountKeyPublic.create(credentials1.getEcKeyPair().getPublicKey()),
                AccountKeyPublic.create(credentials2.getEcKeyPair().getPublicKey()),
                getRoleFeePayer()
        ));
    }

    private AccountKeyWeightedMultiSig getRoleFeePayer() {
        return AccountKeyWeightedMultiSig.create(
                BigInteger.valueOf(5),
                Arrays.asList(
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(2),
                                AccountKeyPublic.create(credentials1.getEcKeyPair().getPublicKey())
                        ),
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(2),
                                AccountKeyPublic.create(credentials2.getEcKeyPair().getPublicKey())
                        ),
                        AccountKeyWeightedMultiSig.WeightedPublicKey.create(
                                BigInteger.valueOf(1),
                                AccountKeyPublic.create(credentials3.getEcKeyPair().getPublicKey())
                        )
                )
        );
    }

    private void setUpAccount(TransactionManager transactionManager) throws Exception {
        ECKeyPair key1 = Keys.createEcKeyPair();
        setUpCreateAccount(transactionManager, key1);
        credentials1 = KlayCredentials.create(key1);

        ECKeyPair key2 = Keys.createEcKeyPair();
        setUpCreateAccount(transactionManager, key2);
        credentials2 = KlayCredentials.create(key2);

        ECKeyPair key3 = Keys.createEcKeyPair();
        setUpCreateAccount(transactionManager, key3);
        credentials3 = KlayCredentials.create(key3);
    }

    private void setUpCreateAccount(TransactionManager transactionManager, ECKeyPair key) throws Exception {
        AccountCreationTransaction accountCreationTransaction = AccountCreationTransaction.create(
                BRANDON.getAddress(),
                Keys.getAddress(key),
                Convert.toPeb("0.2", Convert.Unit.KLAY).toBigInteger(),
                GAS_LIMIT,
                AccountKeyPublic.create(key.getPublicKey())
        );
        transactionManager.executeTransaction(accountCreationTransaction);
    }

}

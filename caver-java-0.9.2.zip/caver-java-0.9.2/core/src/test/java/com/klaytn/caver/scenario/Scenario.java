// Copyright 2019 The caver-java Authors

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.scenario;

import com.klaytn.caver.Caver;
import com.klaytn.caver.crpyto.KlayCredentials;
import com.klaytn.caver.fee.FeePayerManager;
import com.klaytn.caver.methods.response.Bytes32;
import com.klaytn.caver.methods.response.KlayTransactionReceipt;
import com.klaytn.caver.utils.ChainId;
import com.klaytn.caver.utils.Convert;
import com.klaytn.caver.utils.HumanReadableAddressUtils;
import com.klaytn.caver.tx.type.TxType;
import org.junit.Before;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.core.Response;
import org.web3j.tx.gas.StaticGasProvider;

import java.math.BigInteger;
import java.util.Optional;

import static junit.framework.TestCase.fail;

/**
 * Common methods & settings used across scenarios
 */
public class Scenario {

    static final BigInteger GAS_PRICE = Convert.toPeb("25", Convert.Unit.STON).toBigInteger();
    static final BigInteger GAS_LIMIT = BigInteger.valueOf(4_300_000);
    static final StaticGasProvider STATIC_GAS_PROVIDER = new StaticGasProvider(GAS_PRICE, GAS_LIMIT);
    public static final int BAOBAB_CHAIN_ID = ChainId.BAOBAB_TESTNET;

    private static final String WALLET_PASSWORD = "";

    private static final BigInteger ACCOUNT_UNLOCK_DURATION = BigInteger.valueOf(30);

    private static final int SLEEP_DURATION = 2000;
    private static final int ATTEMPTS = 15;

    Caver caver;

    public Scenario() {
    }

    @Before
    public void setUp() {
        this.caver = Caver.build(Caver.BAOBAB_URL);
    }

    BigInteger getNonce(String address) throws Exception {
        BigInteger nonce = caver.klay().getTransactionCount(
                HumanReadableAddressUtils.toRawAddress(address),
                DefaultBlockParameterName.PENDING).sendAsync().get().getValue();

        return nonce;
    }

    String signTransaction(TxType tx, KlayCredentials credentials) {
        return tx.sign(credentials, BAOBAB_CHAIN_ID).getValueAsString();
    }

    String signTransactionFromFeePayer(String senderRawTx, KlayCredentials feePayer) {
        FeePayerManager feePayerManager = new FeePayerManager.Builder(this.caver, feePayer).build();
        return feePayerManager.sign(senderRawTx).getValueAsString();
    }

    KlayTransactionReceipt.TransactionReceipt sendTxAndGetReceipt(String rawTx) throws Exception {
        Bytes32 response = caver.klay().sendSignedTransaction(rawTx).send();
        return waitForTransactionReceipt(response.getResult());
    }

    KlayTransactionReceipt.TransactionReceipt waitForTransactionReceipt(
            String transactionHash) throws Exception {

        Optional<KlayTransactionReceipt.TransactionReceipt> transactionReceiptOptional =
                getTransactionReceipt(transactionHash, SLEEP_DURATION, ATTEMPTS);

        if (!transactionReceiptOptional.isPresent()) {
            fail("Transaction receipt not generated after " + ATTEMPTS + " attempts");
        }

        return transactionReceiptOptional.get();
    }

    private Optional<KlayTransactionReceipt.TransactionReceipt> getTransactionReceipt(
            String transactionHash, int sleepDuration, int attempts) throws Exception {

        Optional<KlayTransactionReceipt.TransactionReceipt> receiptOptional =
                sendTransactionReceiptRequest(transactionHash);
        for (int i = 0; i < attempts; i++) {
            if (!receiptOptional.isPresent()) {
                Thread.sleep(sleepDuration);
                receiptOptional = sendTransactionReceiptRequest(transactionHash);
            } else {
                break;
            }
        }

        return receiptOptional;
    }

    private Optional<KlayTransactionReceipt.TransactionReceipt> sendTransactionReceiptRequest(
            String transactionHash) throws Exception {
        Response<KlayTransactionReceipt.TransactionReceipt> transactionReceipt =
                caver.klay().getTransactionReceipt(transactionHash).sendAsync().get();

        return Optional.ofNullable(transactionReceipt.getResult());
    }
}

package com.klaytn.caver.feature;

import com.klaytn.caver.wallet.WalletManager;
import com.klaytn.caver.wallet.exception.CredentialNotFoundException;
import org.junit.Test;

import static com.klaytn.caver.base.Accounts.BRANDON;
import static com.klaytn.caver.base.Accounts.LUMAN;
import static org.junit.Assert.assertEquals;

public class WalletManagerTest {

    @Test
    public void testDefaultWhenOnlyOne() throws CredentialNotFoundException {
        WalletManager walletManager = new WalletManager();
        walletManager.add(BRANDON);
        assertEquals(BRANDON, walletManager.getDefault());
    }

    @Test
    public void testDefaultWhenManyCredentials() throws CredentialNotFoundException {
        WalletManager walletManager = new WalletManager();
        walletManager.add(BRANDON);
        walletManager.add(LUMAN);
        assertEquals(BRANDON, walletManager.getDefault());
        assertEquals(LUMAN, walletManager.findByAddress(LUMAN.getAddress()));
        assertEquals(BRANDON, walletManager.findByAddress(BRANDON.getAddress()));
    }

    @Test(expected = CredentialNotFoundException.class)
    public void testDefaultWhenNull() throws CredentialNotFoundException {
        WalletManager walletManager = new WalletManager();
        walletManager.getDefault();
    }
}

// Modifications copyright 2019 The caver-java Authors
// Copyright 2016 Conor Svensson

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver;

import com.klaytn.caver.methods.response.Bytes;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.Web3jService;
import org.web3j.protocol.core.Request;
import org.web3j.protocol.core.methods.response.NetListening;
import org.web3j.protocol.core.methods.response.NetPeerCount;

import java.util.Collections;

public class JsonRpc2_0Net implements Net {

    private Web3j web3j;
    protected final Web3jService web3jService;

    public JsonRpc2_0Net(Web3jService web3jService, Web3j web3j) {
        this.web3j = web3j;
        this.web3jService = web3jService;
    }

    @Override
    public Request<?, Bytes> getNetworkId() {
        return new Request<>(
                "net_networkID",
                Collections.<String>emptyList(),
                web3jService,
                Bytes.class);
    }

    @Override
    public Request<?, NetListening> isListening() {
        return web3j.netListening();
    }

    @Override
    public Request<?, NetPeerCount> getPeerCount() {
        return web3j.netPeerCount();
    }

}

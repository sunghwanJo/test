// Modifications copyright 2019 The caver-java Authors
// Copyright 2016 Conor Svensson

// Licensed under the Apache License, Version 2.0 (the “License”);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an “AS IS” BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package com.klaytn.caver.tx.type;

import com.klaytn.caver.tx.account.AccountKey;
import com.klaytn.caver.utils.HumanReadableAddressUtils;
import org.web3j.rlp.RlpString;
import org.web3j.rlp.RlpType;
import org.web3j.utils.Numeric;

import java.math.BigInteger;
import java.util.List;

/**
 * TxTypeAccountCreation creates an externally owned account with the given account key.
 */
public class TxTypeAccountCreation extends AbstractTxType {

    /**
     * if true, this transaction creates a human-readable address.
     * NOTE: if creating an account having a human-readable address,
     * the allowed characters are specified in Specification for New Accounts and Transactions#Charactersallowed.
     */
    private final boolean isHumanReadable;

    /**
     * newly created accountKey
     */
    private final AccountKey accountKey;

    protected TxTypeAccountCreation(
            BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to, BigInteger value,
            String from, boolean isHumanReadable, AccountKey accountKey) {
        super(nonce, gasPrice, gasLimit, from, to, value);
        this.isHumanReadable = isHumanReadable;
        this.accountKey = accountKey;
    }

    public static TxTypeAccountCreation createTransaction(
            BigInteger nonce, BigInteger gasPrice, BigInteger gasLimit, String to, BigInteger value,
            String from, AccountKey accountKey) {
        boolean isHumanReadable = HumanReadableAddressUtils.isHumanReadableAddress(to);
        return new TxTypeAccountCreation(nonce, gasPrice, gasLimit, to, value, from, isHumanReadable, accountKey);
    }

    public boolean isHumanReadable() {
        return isHumanReadable;
    }

    public AccountKey getAccountKey() {
        return accountKey;
    }

    /**
     * This method is overridden as ACCOUNT_CREATION type.
     * The return value is used for rlp encoding.
     *
     * @return Type transaction type
     */
    @Override
    public Type getType() {
        return Type.ACCOUNT_CREATION;
    }

    /**
     * create RlpType List which contains nonce, gas price, gas limit, to, value, from, isHumanReadable and accountKey
     * List elements can be different depending on transaction type.
     *
     * @return List RlpType List
     */
    @Override
    public List<RlpType> rlpValues() {
        List<RlpType> result = super.rlpValues();
        result.add(RlpString.create(Numeric.hexStringToByteArray(getTo())));
        result.add(RlpString.create(getValue()));
        result.add(RlpString.create(Numeric.hexStringToByteArray(getFrom())));
        result.add(RlpString.create(isHumanReadable() ? 0x1 : 0x0));
        result.add(RlpString.create(getAccountKey().toRlp()));
        return result;
    }
}
